
-repackageclasses ''
-flattenpackagehierarchy ''
-allowaccessmodification
-overloadaggressively
-mergeinterfacesaggressively
-optimizationpasses 5

-renamesourcefileattribute ''
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**
-dontwarn org.checkerframework.**
-dontwarn kotlin.Metadata
-dontwarn kotlin.jvm.internal.**

-keep,allowobfuscation class com.mr.wallet.DecoyGuard { *; }
