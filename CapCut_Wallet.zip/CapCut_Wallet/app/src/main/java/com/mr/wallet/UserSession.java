package com.mr.wallet;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public final class UserSession {
    private UserSession() {}

    public interface Callback {
        void onReady(String userId);
        void onError(String message);
    }

    private static final String PREFS = "wallet_prefs";
    private static final String KEY = "user_id";

    @Nullable
    public static String getId(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null);
    }

    public static void ensure(final Context c, final Callback cb) {
        final Context app = c.getApplicationContext();
        AuthGate.ensure(new AuthGate.Done() {
            @Override public void onOk() {
                String existing = getId(app);
                if (existing != null) {
                    cb.onReady(existing);
                    return;
                }
                tryCreate(app, cb, 0);
            }
            @Override public void onFail(String message) { cb.onError(message); }
        });
    }

    private static void tryCreate(final Context app, final Callback cb, final int attempt) {
        if (attempt >= 12) {
            cb.onError("ইউজার আইডি তৈরি করা যায়নি। ইন্টারনেট চেক করে আবার চেষ্টা করুন।");
            return;
        }
        final String id = "USER-" + (10000 + new Random().nextInt(90000));
        final DatabaseReference ref = Db.ref("users").child(id);
        ref.runTransaction(new Transaction.Handler() {
            @NonNull @Override
            public Transaction.Result doTransaction(@NonNull MutableData d) {
                if (d.getValue() != null) return Transaction.abort();
                Map<String, Object> m = new HashMap<>();
                m.put("createdAt", ServerValue.TIMESTAMP);
                d.setValue(m);
                return Transaction.success(d);
            }

            @Override
            public void onComplete(@Nullable DatabaseError e, boolean committed, @Nullable DataSnapshot s) {
                if (e != null) {
                    cb.onError("Firebase সংযোগ ব্যর্থ: " + e.getMessage());
                } else if (committed) {
                    app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, id).apply();
                    cb.onReady(id);
                } else {
                    tryCreate(app, cb, attempt + 1);
                }
            }
        });
    }
}
