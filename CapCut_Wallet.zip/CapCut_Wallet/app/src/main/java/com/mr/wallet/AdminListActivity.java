package com.mr.wallet;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AdminListActivity extends AppCompatActivity {

    private String userId;
    private boolean isBn;
    private double ownerRate = 0.0;

    private LinearLayout root;
    private LinearLayout list;

    private DatabaseReference adminsRef, settingsRef;
    private ValueEventListener adminsListener, settingsListener;
    private DataSnapshot lastAdmins;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        userId = in.getStringExtra("userId");
        if (userId == null) userId = UserSession.getId(this);
        isBn = in.getBooleanExtra("isBn", true);

        final Context c = this;
        root = UI.col(c);
        root.setBackgroundColor(UI.BG);

        TextView title = UI.tv(c,
                isBn ? "অনলাইন এডমিনদের তালিকা (বিক্রি করুন)" : "Online Admin List (Sell USD)",
                14, UI.WHITE, true);
        root.addView(UI.appBar(this, title));

        LinearLayout body = UI.col(c);
        body.setPadding(UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14));

        LinearLayout header = UI.row(c);
        header.addView(UI.tv(c, isBn ? "সক্রিয় অনলাইন এডমিনরা" : "Active Online Admins",
                14, UI.WHITE, true));
        header.addView(UI.flex(c));
        body.addView(header, UI.lp(UI.MATCH, UI.WRAP));
        body.addView(UI.vs(c, 12));

        list = UI.col(c);
        ScrollView scroll = new ScrollView(c);
        scroll.addView(list, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));
        body.addView(scroll, UI.lpw(UI.MATCH, 0, 1f));

        root.addView(body, UI.lpw(UI.MATCH, 0, 1f));
        setContentView(root);

        list.addView(UI.tv(c, isBn ? "লোড হচ্ছে..." : "Loading...", 11, UI.GREY, false));

        settingsRef = Db.ref("system_settings").child("dollar_rate");
        settingsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                Object v = s.getValue();
                try { ownerRate = v == null ? 0.0 : Double.parseDouble(String.valueOf(v).trim()); }
                catch (Exception e) { ownerRate = 0.0; }
                if (lastAdmins != null) renderAdmins();
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { }
        };
        settingsRef.addValueEventListener(settingsListener);

        adminsRef = Db.ref("admins");
        adminsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                lastAdmins = s;
                renderAdmins();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {
                list.removeAllViews();
                list.addView(UI.tv(AdminListActivity.this, "ত্রুটি: " + e.getMessage(), 11, UI.RED_ACCENT, false));
            }
        };
        adminsRef.addValueEventListener(adminsListener);
    }

    @Override
    protected void onDestroy() {
        if (adminsRef != null && adminsListener != null) adminsRef.removeEventListener(adminsListener);
        if (settingsRef != null && settingsListener != null) settingsRef.removeEventListener(settingsListener);
        super.onDestroy();
    }

    private static String str(DataSnapshot s, String k) {
        Object v = s.child(k).getValue();
        return v == null ? "" : String.valueOf(v).trim();
    }

    private static boolean flag(DataSnapshot s, String k) {
        Object v = s.child(k).getValue();
        return (v instanceof Boolean) && (Boolean) v;
    }

    private void renderAdmins() {
        list.removeAllViews();
        List<AdminInfo> online = new ArrayList<>();
        for (DataSnapshot a : lastAdmins.getChildren()) {
            if (flag(a, "isBlocked") || !flag(a, "offerActive")) continue;
            AdminInfo info = new AdminInfo();
            info.id = a.getKey();
            info.name = str(a, "name").isEmpty() ? "Admin" : str(a, "name");
            info.img = str(a, "img");
            try { info.rate = Double.parseDouble(str(a, "rate")); } catch (Exception e) { info.rate = 0.0; }
            if (info.rate <= 0) info.rate = ownerRate;
            info.minUsd = str(a, "minUsd");
            info.maxUsd = str(a, "maxUsd");
            info.countries = str(a, "countries");
            for (DataSnapshot m : a.child("methods").getChildren()) {
                Object v = m.getValue();
                if (v instanceof Boolean && (Boolean) v) info.methods.add(m.getKey());
            }
            online.add(info);
        }
        if (online.isEmpty()) {
            TextView t = UI.tv(this, isBn ? "এখন কোনো এডমিন অনলাইনে নেই। একটু পরে আবার দেখুন।"
                    : "No admin is online right now. Please check again later.", 12, UI.GREY, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, UI.dp(this, 40), 0, 0);
            list.addView(t, UI.lp(UI.MATCH, UI.WRAP));
            return;
        }
        for (AdminInfo a : online) list.addView(buildAdminCard(a));
    }

    private static String flagOf(String country) {
        switch (country) {
            case "Bangladesh": return "🇧🇩 ";
            case "USA": return "🇺🇸 ";
            case "Australia": return "🇦🇺 ";
            case "UK": return "🇬🇧 ";
            case "Canada": return "🇨🇦 ";
            case "India": return "🇮🇳 ";
            case "UAE": return "🇦🇪 ";
            case "Saudi Arabia": return "🇸🇦 ";
            case "Qatar": return "🇶🇦 ";
            case "Kuwait": return "🇰🇼 ";
            case "Oman": return "🇴🇲 ";
            case "Malaysia": return "🇲🇾 ";
            case "Singapore": return "🇸🇬 ";
            case "Vietnam": return "🇻🇳 ";
            case "Indonesia": return "🇮🇩 ";
            case "Philippines": return "🇵🇭 ";
            case "Japan": return "🇯🇵 ";
            case "Germany": return "🇩🇪 ";
            case "France": return "🇫🇷 ";
            case "Brazil": return "🇧🇷 ";
            default: return "";
        }
    }

    private int chipColor(String m) {
        switch (m) {
            case "bKash": return UI.PINK;
            case "Nagad": return UI.ORANGE;
            case "Bank": return UI.BLUE;
            case "USDT": return UI.TEAL;
            case "Rocket": return 0xFF7B1FA2;
            default: return 0xFF607D8B;
        }
    }

    private View buildAdminCard(final AdminInfo admin) {
        Context c = this;

        LinearLayout card = UI.col(c);
        card.setBackground(UI.box(c, UI.CARD, 14, UI.BORDER, 1));
        card.setPadding(UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12));
        card.setLayoutParams(UI.lpm(c, UI.MATCH, UI.WRAP, 0, 0, 0, 12));

        LinearLayout top = UI.row(c);

        FrameLayout avatar = new FrameLayout(c);
        CircleImageView img = new CircleImageView(c);
        avatar.addView(img, new FrameLayout.LayoutParams(UI.dp(c, 40), UI.dp(c, 40)));
        ImageLoader.load(admin.img, img);
        View dot = new View(c);
        dot.setBackground(UI.oval(UI.GREEN_DOT, UI.CARD, UI.dp(c, 2)));
        avatar.addView(dot, new FrameLayout.LayoutParams(UI.dp(c, 11), UI.dp(c, 11),
                Gravity.BOTTOM | Gravity.END));
        top.addView(avatar, UI.lp(UI.dp(c, 40), UI.dp(c, 40)));
        top.addView(UI.hs(c, 10));

        LinearLayout info = UI.col(c);
        LinearLayout nameRow = UI.row(c);
        nameRow.addView(UI.tv(c, admin.name, 13, UI.WHITE, true));
        nameRow.addView(UI.hs(c, 6));
        TextView online = UI.tv(c, isBn ? "অনলাইন" : "Online", 8, UI.GREEN_ACCENT, false);
        online.setBackground(UI.box(c, UI.alpha(UI.GREEN, 0.2f), 4, 0, 0));
        online.setPadding(UI.dp(c, 4), UI.dp(c, 1), UI.dp(c, 4), UI.dp(c, 1));
        nameRow.addView(online, UI.lp(UI.WRAP, UI.WRAP));
        info.addView(nameRow, UI.lp(UI.WRAP, UI.WRAP));
        top.addView(info, UI.lpw(0, UI.WRAP, 1f));

        LinearLayout chatBtn = UI.row(c);
        chatBtn.setGravity(Gravity.CENTER);
        chatBtn.setBackground(UI.clickable(c, UI.EMERALD, 20, 0, 0));
        chatBtn.setPadding(UI.dp(c, 10), UI.dp(c, 6), UI.dp(c, 10), UI.dp(c, 6));
        chatBtn.addView(UI.icon(c, Icons.CHAT_BUBBLE, UI.WHITE, 12));
        chatBtn.addView(UI.hs(c, 6));
        chatBtn.addView(UI.tv(c, isBn ? "চ্যাট করুন" : "Chat", 10, UI.WHITE, true));
        chatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleChatStart(admin);
            }
        });
        top.addView(chatBtn, UI.lp(UI.WRAP, UI.WRAP));
        card.addView(top, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 10));

        boolean hasLimit = !admin.minUsd.isEmpty() || !admin.maxUsd.isEmpty();
        boolean hasCountry = !admin.countries.isEmpty();
        if (hasLimit || hasCountry) {
            LinearLayout limitRow = UI.row(c);
            if (hasLimit) {
                String lo = admin.minUsd.isEmpty() ? "—" : "$" + admin.minUsd;
                String hi = admin.maxUsd.isEmpty() ? "—" : "$" + admin.maxUsd;
                TextView lim = UI.tv(c, (isBn ? "উইথড্র: " : "Withdraw: ") + lo + " – " + hi,
                        9, UI.AMBER, true);
                lim.setBackground(UI.box(c, UI.alpha(UI.AMBER, 0.15f), 4, 0, 0));
                lim.setPadding(UI.dp(c, 6), UI.dp(c, 2), UI.dp(c, 6), UI.dp(c, 2));
                limitRow.addView(lim, UI.lp(UI.WRAP, UI.WRAP));
            }
            limitRow.addView(UI.flex(c));
            if (hasCountry) {
                LinearLayout cchips = UI.row(c);
                for (String code : admin.countries.split(",")) {
                    code = code.trim();
                    if (code.isEmpty()) continue;
                    String label;
                    if (code.equalsIgnoreCase("all")) label = isBn ? "সব দেশ" : "All";
                    else {
                        if (code.equalsIgnoreCase("BD")) code = "Bangladesh";
                        else if (code.equalsIgnoreCase("US")) code = "USA";
                        label = flagOf(code) + code;
                    }
                    TextView chip = UI.tv(c, label, 8, UI.WHITE, true);
                    chip.setBackground(UI.box(c, UI.alpha(UI.TEAL, 0.85f), 4, 0, 0));
                    chip.setPadding(UI.dp(c, 6), UI.dp(c, 2), UI.dp(c, 6), UI.dp(c, 2));
                    cchips.addView(chip, UI.lpm(c, UI.WRAP, UI.WRAP, 4, 0, 0, 0));
                }
                limitRow.addView(cchips, UI.lp(UI.WRAP, UI.WRAP));
            }
            card.addView(limitRow, UI.lp(UI.MATCH, UI.WRAP));
            card.addView(UI.vs(c, 8));
        }

        LinearLayout bottom = UI.row(c);
        LinearLayout left = UI.col(c);
        TextView rate = UI.tv(c, admin.rate > 0
                        ? "$1 = ৳ " + String.format(Locale.US, "%.2f", admin.rate) + " BDT" : "$1 = —",
                9, UI.BLUE_ACCENT, true);
        rate.setBackground(UI.box(c, UI.alpha(UI.BLUE, 0.15f), 4, 0, 0));
        rate.setPadding(UI.dp(c, 6), UI.dp(c, 2), UI.dp(c, 6), UI.dp(c, 2));
        left.addView(rate, UI.lp(UI.WRAP, UI.WRAP));
        bottom.addView(left, UI.lp(UI.WRAP, UI.WRAP));
        bottom.addView(UI.flex(c));

        LinearLayout chips = UI.row(c);
        for (String m : admin.methods) {
            TextView chip = UI.tv(c, m, 8, UI.WHITE, true);
            chip.setBackground(UI.box(c, UI.alpha(chipColor(m), 0.85f), 4, 0, 0));
            chip.setPadding(UI.dp(c, 6), UI.dp(c, 2), UI.dp(c, 6), UI.dp(c, 2));
            chips.addView(chip, UI.lpm(c, UI.WRAP, UI.WRAP, 4, 0, 0, 0));
        }
        bottom.addView(chips, UI.lp(UI.WRAP, UI.WRAP));
        card.addView(bottom, UI.lp(UI.MATCH, UI.WRAP));
        return card;
    }

    private void handleChatStart(AdminInfo admin) {
        SharedPreferences prefs = getSharedPreferences("wallet_prefs", MODE_PRIVATE);
        long lastChatTimestamp = prefs.getLong("last_chat_timestamp", 0L);
        String lastAdminId = prefs.getString("last_admin_id", "");
        if (lastAdminId == null) lastAdminId = "";

        long now = System.currentTimeMillis();
        long differenceInMinutes = (now - lastChatTimestamp) / (1000L * 60L);

        if (!TextUtils.isEmpty(lastAdminId)
                && !lastAdminId.equals(admin.id)
                && differenceInMinutes < 10) {
            long remaining = 10 - differenceInMinutes;
            UI.snack(root,
                    isBn ? "নতুন এডমিনকে মেসেজ করতে আরও " + remaining + " মিনিট অপেক্ষা করুন।"
                            : "Please wait " + remaining + " minutes to text another admin.",
                    UI.RED_ACCENT, Snackbar.LENGTH_LONG);
            return;
        }

        if (!lastAdminId.equals(admin.id)) {
            prefs.edit()
                    .putLong("last_chat_timestamp", now)
                    .putString("last_admin_id", admin.id)
                    .apply();
        }

        Intent i = new Intent(this, ChatActivity.class);
        admin.putTo(i);
        i.putExtra("userId", userId);
        i.putExtra("isBn", isBn);
        startActivity(i);
    }
}
