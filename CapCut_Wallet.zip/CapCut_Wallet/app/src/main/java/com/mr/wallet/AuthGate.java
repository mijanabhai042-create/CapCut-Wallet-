package com.mr.wallet;

import com.google.firebase.auth.FirebaseAuth;

public final class AuthGate {
    private AuthGate() {}

    public interface Done {
        void onOk();
        void onFail(String message);
    }

    public static void ensure(final Done done) {
        final FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            done.onOk();
            return;
        }
        auth.signInAnonymously().addOnCompleteListener(task -> {
            if (task.isSuccessful() && auth.getCurrentUser() != null) {
                done.onOk();
            } else {
                done.onFail("লগইন ব্যর্থ। ইন্টারনেট চেক করে আবার চেষ্টা করুন।");
            }
        });
    }
}
