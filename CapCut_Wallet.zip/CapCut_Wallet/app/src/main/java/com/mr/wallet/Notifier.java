package com.mr.wallet;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public final class Notifier {
    private Notifier() {}

    public static final String CH_ALERT = "alerts";
    public static final String CH_SERVICE = "service";

    public static volatile String activeChat = "";

    private static boolean asked = false;

    public static void ensureEnabled(final android.app.Activity a) {
        if (asked || a.isFinishing()) return;
        if (NotificationManagerCompat.from(a).areNotificationsEnabled()) return;
        asked = true;
        new androidx.appcompat.app.AlertDialog.Builder(a)
                .setTitle("নোটিফিকেশন বন্ধ আছে / Notifications are off")
                .setMessage("মেসেজ, আপডেট ও নোটিশ ফোনে পেতে নোটিফিকেশন চালু করুন।\nTurn on notifications to receive messages, updates and notices.")
                .setPositiveButton("চালু করুন / Open settings", (d, w) -> {
                    Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                    a.startActivity(i);
                })
                .setNegativeButton("পরে / Later", null)
                .show();
    }

    public static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel(CH_ALERT, "Messages & Updates", NotificationManager.IMPORTANCE_HIGH));
        nm.createNotificationChannel(new NotificationChannel(CH_SERVICE, "Background sync", NotificationManager.IMPORTANCE_MIN));
    }

    public static Notification serviceNotification(Context c) {
        return new NotificationCompat.Builder(c, CH_SERVICE)
                .setSmallIcon(android.R.drawable.stat_notify_sync_noanim)
                .setContentTitle("CapCut")
                .setContentText("Connected")
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true)
                .build();
    }

    public static void show(Context c, int id, String title, String body) {
        createChannels(c);
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        PendingIntent pi = null;
        if (open != null) {
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            pi = PendingIntent.getActivity(c, id, open, flags);
        }
        Notification n = new NotificationCompat.Builder(c, CH_ALERT)
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        try { if (nm != null) nm.notify(id, n); } catch (SecurityException ignored) { }
    }
}
