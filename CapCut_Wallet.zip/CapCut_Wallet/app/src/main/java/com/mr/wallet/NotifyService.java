package com.mr.wallet;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class NotifyService extends Service {

    private DatabaseReference inboxRef, settingsRef;
    private ChildEventListener inboxListener;
    private ValueEventListener settingsListener;
    private SharedPreferences prefs;

    public static void start(Context c) {
        try { ContextCompat.startForegroundService(c, new Intent(c, NotifyService.class)); }
        catch (Exception ignored) { }
    }

    public static void stop(Context c) {
        try { c.stopService(new Intent(c, NotifyService.class)); } catch (Exception ignored) { }
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notifier.createChannels(this);
        try {
            ServiceCompat.startForeground(this, 7001, Notifier.serviceNotification(this),
                    Build.VERSION.SDK_INT >= 34 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE : -1);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        attach();
        return START_STICKY;
    }

    private void attach() {
        detach();
        prefs = getSharedPreferences("notify_seen", MODE_PRIVATE);
        final String me = UserSession.getId(this);
        if (me == null || me.isEmpty()) { stopSelf(); return; }
        if (com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser() == null) {
            AuthGate.ensure(new AuthGate.Done() {
                @Override public void onOk() { attach(); }
                @Override public void onFail(String message) { stopSelf(); }
            });
            return;
        }

        inboxRef = Db.ref("notifications").child(me);
        inboxListener = new ChildEventListener() {
            @Override public void onChildAdded(@NonNull DataSnapshot s, @Nullable String prev) {
                String title = String.valueOf(s.child("title").getValue());
                String body = String.valueOf(s.child("body").getValue());
                Object chat = s.child("chat").getValue();
                String chatKey = chat == null ? "" : String.valueOf(chat);
                if (chatKey.isEmpty() || !chatKey.equals(Notifier.activeChat)) {
                    Notifier.show(NotifyService.this, (int) (System.nanoTime() & 0x7fffffff), title, body);
                }
                s.getRef().removeValue();
            }
            @Override public void onChildChanged(@NonNull DataSnapshot s, @Nullable String p) { }
            @Override public void onChildRemoved(@NonNull DataSnapshot s) { }
            @Override public void onChildMoved(@NonNull DataSnapshot s, @Nullable String p) { }
            @Override public void onCancelled(@NonNull DatabaseError e) { }
        };
        inboxRef.addChildEventListener(inboxListener);

        settingsRef = Db.ref("system_settings");
        settingsListener = new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot s) {
                checkTs(s, "wallet_notice_ts", "CapCut Notice", str(s, "wallet_notice_text"));
                checkTs(s, "wallet_update_ts", "App Update", "নতুন আপডেট এসেছে। অ্যাপ আপডেট করুন।");
                checkTs(s, "dollar_rate_ts", "ডলার রেট পরিবর্তন", "নতুন রেট: ১ ডলার = ৳ " + str(s, "dollar_rate"));
            }
            @Override public void onCancelled(@NonNull DatabaseError e) { }
        };
        settingsRef.addValueEventListener(settingsListener);
    }

    private void checkTs(DataSnapshot s, String tsKey, String title, String body) {
        Object v = s.child(tsKey).getValue();
        if (!(v instanceof Number)) return;
        long ts = ((Number) v).longValue();
        long seen = prefs.getLong(tsKey, -1L);
        if (seen == -1L) {
            prefs.edit().putLong(tsKey, ts).apply();
            return;
        }
        if (ts > seen) {
            prefs.edit().putLong(tsKey, ts).apply();
            Notifier.show(this, tsKey.hashCode() & 0x7fffffff, title, body.isEmpty() ? title : body);
        }
    }

    private static String str(DataSnapshot s, String k) {
        Object v = s.child(k).getValue();
        return v == null ? "" : String.valueOf(v);
    }

    private void detach() {
        if (inboxRef != null && inboxListener != null) inboxRef.removeEventListener(inboxListener);
        if (settingsRef != null && settingsListener != null) settingsRef.removeEventListener(settingsListener);
        inboxRef = null; settingsRef = null; inboxListener = null; settingsListener = null;
    }

    @Override public void onDestroy() { detach(); super.onDestroy(); }
}
