package com.mr.wallet;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class ChatActivity extends AppCompatActivity {

    private String activeKey = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        AdminInfo admin = AdminInfo.from(in);
        String userId = in.getStringExtra("userId");
        if (userId == null) userId = UserSession.getId(this);
        boolean isBn = in.getBooleanExtra("isBn", true);
        activeKey = admin.id;

        Context c = this;
        LinearLayout root = UI.col(c);
        root.setBackgroundColor(UI.BG);

        LinearLayout titleRow = UI.row(c);

        FrameLayout avatar = new FrameLayout(c);
        CircleImageView img = new CircleImageView(c);
        avatar.addView(img, new FrameLayout.LayoutParams(UI.dp(c, 28), UI.dp(c, 28)));
        ImageLoader.load(admin.img, img);
        android.view.View dot = new android.view.View(c);
        dot.setBackground(UI.oval(UI.GREEN_DOT, UI.APPBAR, UI.dp(c, 1.5f)));
        avatar.addView(dot, new FrameLayout.LayoutParams(UI.dp(c, 8), UI.dp(c, 8),
                Gravity.BOTTOM | Gravity.END));
        titleRow.addView(avatar, UI.lp(UI.dp(c, 28), UI.dp(c, 28)));
        titleRow.addView(UI.hs(c, 8));

        LinearLayout names = UI.col(c);
        names.addView(UI.tv(c, admin.name, 13, UI.WHITE, true));
        names.addView(UI.tv(c, isBn ? "অনলাইনে আছেন" : "Online", 8, UI.GREEN_ACCENT, false));
        titleRow.addView(names, UI.lp(UI.WRAP, UI.WRAP));

        root.addView(UI.appBar(this, titleRow));

        ChatView chat = new ChatView(c, userId, isBn, admin);
        root.addView(chat, UI.lpw(UI.MATCH, 0, 1f));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Notifier.activeChat = activeKey;
    }

    @Override
    protected void onPause() {
        Notifier.activeChat = "";
        super.onPause();
    }
}
