package com.mr.wallet;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private String currentLang = "bn";
    private double ownerRate = 0.0;
    private String rateTitle = "";
    private String updateNotice = "";
    private String updateDescription = "";
    private String updateUrl = "";
    private String noticeLink = "";
    private long updateTs = 0L;
    private boolean forceUpdate = false;
    private String buyPhone = "";
    private String buyEmail = "";

    private DatabaseReference settingsRef;
    private ValueEventListener settingsListener;
    private Dialog updateDialog;
    private boolean ready = false;

    private int selectedIndex = 0;
    private double usdInput = 1.0;
    private String usdText = "1.0";
    private String userId = "";

    private FrameLayout appBarContainer;
    private FrameLayout contentContainer;
    private LinearLayout bottomNavContainer;
    private ChatView supportChat;

    private boolean isBn() {
        return currentLang.equals("bn");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        appBarContainer = findViewById(R.id.appBarContainer);
        contentContainer = findViewById(R.id.contentContainer);
        bottomNavContainer = findViewById(R.id.bottomNavContainer);
        showLoading(null);
        startSession();
    }

    private void showLoading(String error) {
        appBarContainer.removeAllViews();
        bottomNavContainer.removeAllViews();
        contentContainer.removeAllViews();
        LinearLayout box = UI.col(this);
        box.setGravity(Gravity.CENTER);
        if (error == null) {
            box.addView(new android.widget.ProgressBar(this), UI.lp(UI.WRAP, UI.WRAP));
            box.addView(UI.vs(this, 12));
            TextView lt = UI.tv(this, "লোড হচ্ছে...", 12, UI.GREY, false);
            lt.setGravity(Gravity.CENTER);
            box.addView(lt, UI.lp(UI.MATCH, UI.WRAP));
        } else {
            TextView t = UI.tv(this, error, 12, UI.WHITE, false);
            t.setGravity(Gravity.CENTER);
            box.addView(t, UI.lp(UI.WRAP, UI.WRAP));
            box.addView(UI.vs(this, 14));
            TextView retry = UI.tv(this, "আবার চেষ্টা করুন", 12, UI.WHITE, true);
            retry.setBackground(UI.clickable(this, UI.PRIMARY, 20, 0, 0));
            retry.setPadding(UI.dp(this, 20), UI.dp(this, 10), UI.dp(this, 20), UI.dp(this, 10));
            retry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showLoading(null);
                    startSession();
                }
            });
            box.addView(retry, UI.lp(UI.WRAP, UI.WRAP));
        }
        contentContainer.addView(box, new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));
    }

    private void startSession() {
        UserSession.ensure(this, new UserSession.Callback() {
            @Override
            public void onReady(String id) {
                if (isFinishing() || isDestroyed()) return;
                userId = id;
                requestNotificationPermission();
                NotifyService.start(MainActivity.this);
                listenSettings();
            }

            @Override
            public void onError(String message) {
                if (isFinishing() || isDestroyed()) return;
                showLoading(message);
            }
        });
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    private void listenSettings() {
        if (settingsListener != null) return;
        settingsRef = Db.ref("system_settings");
        settingsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                ownerRate = parseDouble(str(s, "dollar_rate"));
                rateTitle = str(s, "dollar_rate_title").trim();
                buyPhone = str(s, "buy_phone");
                buyEmail = str(s, "buy_email");
                updateNotice = str(s, "wallet_notice_text");
                noticeLink = str(s, "wallet_notice_link");
                updateDescription = "";
                updateUrl = str(s, "wallet_app_update_link");
                Object ts = s.child("wallet_notice_ts").getValue();
                updateTs = (ts instanceof Number) ? ((Number) ts).longValue() : 0L;
                Object f = s.child("wallet_force_update").getValue();
                forceUpdate = (f instanceof Boolean) && (Boolean) f;
                ready = true;
                render();
                syncUpdateDialog();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {
                if (!ready) showLoading("ডাটা লোড করা যায়নি: " + e.getMessage());
            }
        };
        settingsRef.addValueEventListener(settingsListener);
    }

    private static String str(DataSnapshot s, String k) {
        Object v = s.child(k).getValue();
        return v == null ? "" : String.valueOf(v).trim();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Notifier.ensureEnabled(this);
    }

    @Override
    protected void onDestroy() {
        if (settingsRef != null && settingsListener != null) settingsRef.removeEventListener(settingsListener);
        if (updateDialog != null && updateDialog.isShowing()) updateDialog.dismiss();
        super.onDestroy();
    }

    private void syncUpdateDialog() {
        if (!forceUpdate) {
            if (updateDialog != null && updateDialog.isShowing()) updateDialog.dismiss();
            updateDialog = null;
            return;
        }
        if (updateDialog != null && updateDialog.isShowing()) return;

        Context c = this;
        updateDialog = UI.newDialog(c);
        updateDialog.setCancelable(false);
        LinearLayout card = UI.dialogCard(c);
        card.addView(UI.icon(c, Icons.CAMPAIGN, UI.AMBER, 34), UI.centered(c, 4));
        card.addView(UI.vs(c, 10));
        TextView t = UI.tv(c, isBn() ? "নতুন আপডেট এসেছে!" : "New Update Available!", 16, UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        card.addView(t, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 10));
        String msg = isBn() ? "অ্যাপটির নতুন ভার্সন এসেছে। চালিয়ে যেতে আপডেট করুন।" : "A new version is available. Please update to continue.";
        TextView b = UI.tv(c, msg, 12, UI.GREY, false);
        b.setGravity(Gravity.CENTER);
        card.addView(b, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 16));

        TextView btn = UI.tv(c, isBn() ? "আপডেট করুন" : "Update Now", 13, UI.WHITE, true);
        btn.setGravity(Gravity.CENTER);
        btn.setBackground(UI.clickable(c, UI.PRIMARY, 12, 0, 0));
        btn.setPadding(0, UI.dp(c, 12), 0, UI.dp(c, 12));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink(updateUrl);
            }
        });
        card.addView(btn, UI.lp(UI.MATCH, UI.WRAP));
        UI.showCard(updateDialog, card);
    }

    private void openLink(String url) {
        if (url == null || url.isEmpty()) return;
        String u = url.startsWith("http") ? url : "https://" + url;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        } catch (Exception e) {
            UI.copyToClipboard(this, url);
            UI.snack(contentContainer, isBn() ? "লিংক কপি করা হয়েছে!" : "Link copied!", 0, Snackbar.LENGTH_SHORT);
        }
    }

    void changeLanguage(String lang) {
        currentLang = lang;
        render();
    }

    private void selectTab(int index) {
        selectedIndex = index;
        if (index == 1 && updateTs > 0) {
            getSharedPreferences("wallet_prefs", MODE_PRIVATE).edit().putLong("seen_update_ts", updateTs).apply();
        }
        render();
    }

    private void render() {
        if (!ready) return;
        buildAppBar();
        buildBody();
        buildBottomNav();
    }

    private void buildAppBar() {
        final Context c = this;
        appBarContainer.removeAllViews();

        LinearLayout bar = UI.row(c);
        bar.setBackgroundColor(UI.APPBAR);
        bar.setPadding(UI.dp(c, 16), 0, UI.dp(c, 8), 0);

        FrameLayout logo = new FrameLayout(c);
        logo.setBackground(UI.box(c, UI.PRIMARY, 10, 0, 0));
        logo.addView(UI.tv(c, "C", 18, UI.WHITE, true),
                new FrameLayout.LayoutParams(UI.WRAP, UI.WRAP, Gravity.CENTER));
        bar.addView(logo, UI.lp(UI.dp(c, 36), UI.dp(c, 36)));
        bar.addView(UI.hs(c, 10));

        LinearLayout titles = UI.col(c);
        titles.addView(UI.tv(c, "CapCut Wallet", 15, UI.WHITE, true));
        titles.addView(UI.tv(c, isBn() ? "নিরাপদ • দ্রুত • বিশ্বস্ত" : "Safe • Fast • Trusted",
                10, UI.GREY, false));
        bar.addView(titles, UI.lpw(0, UI.WRAP, 1f));

        if (selectedIndex == 3) {
            bar.addView(UI.iconButton(c, Icons.SETTINGS, UI.BLUE_ACCENT, 24, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSettingsDialog();
                }
            }));
        } else {
            FrameLayout bell = new FrameLayout(c);
            FrameLayout btn = UI.iconButton(c, Icons.NOTIFICATIONS, UI.AMBER, 24, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectTab(1);
                }
            });
            bell.addView(btn, new FrameLayout.LayoutParams(UI.dp(c, 48), UI.dp(c, 48)));

            long seenTs = getSharedPreferences("wallet_prefs", MODE_PRIVATE).getLong("seen_update_ts", 0L);
            TextView badge = UI.tv(c, "1", 8, UI.WHITE, true);
            badge.setVisibility(updateTs > seenTs ? View.VISIBLE : View.GONE);
            badge.setGravity(Gravity.CENTER);
            badge.setBackground(UI.oval(UI.RED, 0, 0));
            badge.setPadding(UI.dp(c, 3), UI.dp(c, 1), UI.dp(c, 3), UI.dp(c, 1));
            badge.setMinWidth(UI.dp(c, 14));
            badge.setMinHeight(UI.dp(c, 14));
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(UI.WRAP, UI.WRAP,
                    Gravity.TOP | Gravity.END);
            bp.topMargin = UI.dp(c, 10);
            bp.rightMargin = UI.dp(c, 8);
            bell.addView(badge, bp);
            bar.addView(bell, UI.lp(UI.dp(c, 48), UI.dp(c, 48)));
        }
        bar.addView(UI.hs(c, 8));

        appBarContainer.addView(bar, new FrameLayout.LayoutParams(UI.MATCH, UI.dp(c, 56)));
    }

    private void buildBottomNav() {
        final Context c = this;
        bottomNavContainer.removeAllViews();

        View line = new View(c);
        line.setBackgroundColor(UI.BORDER);
        bottomNavContainer.addView(line, UI.lp(UI.MATCH, 1));

        LinearLayout items = UI.row(c);
        items.setBackgroundColor(UI.APPBAR);

        String[] labels = {
                isBn() ? "হোম" : "Home",
                isBn() ? "ক্যাপকাট আপডেট" : "Capcut Update",
                isBn() ? "সাপোর্ট" : "Support",
                isBn() ? "প্রোফাইল" : "Profile",
        };
        String[] icons = {Icons.HOME, Icons.MOVIE, Icons.HEADSET, Icons.PERSON};

        for (int i = 0; i < 4; i++) {
            final int index = i;
            int color = (i == selectedIndex) ? UI.SKY : UI.GREY;

            LinearLayout item = UI.col(c);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            item.setBackground(UI.clickable(c, 0, 0, 0, 0));
            item.setPadding(UI.dp(c, 4), UI.dp(c, 8), UI.dp(c, 4), UI.dp(c, 8));
            item.addView(UI.icon(c, icons[i], color, 24));
            item.addView(UI.vs(c, 4));
            TextView label = UI.tv(c, labels[i], 11, color, false);
            label.setSingleLine(true);
            label.setEllipsize(TextUtils.TruncateAt.END);
            label.setGravity(Gravity.CENTER);
            item.addView(label, UI.lp(UI.WRAP, UI.WRAP));
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectTab(index);
                }
            });
            items.addView(item, UI.lpw(0, UI.WRAP, 1f));
        }
        bottomNavContainer.addView(items, UI.lp(UI.MATCH, UI.WRAP));
    }

    private void buildBody() {
        contentContainer.removeAllViews();
        switch (selectedIndex) {
            case 1:
                contentContainer.addView(buildUpdateTab(),
                        new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));
                break;
            case 2:
                contentContainer.addView(buildSupportTab(),
                        new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));
                break;
            case 3:
                contentContainer.addView(buildProfileTab(),
                        new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));
                break;
            case 0:
            default:
                contentContainer.addView(buildHomeTab(),
                        new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));
                break;
        }
    }

    private View buildHomeTab() {
        final Context c = this;
        ScrollView scroll = new ScrollView(c);
        LinearLayout page = UI.col(c);
        page.setPadding(UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14));
        scroll.addView(page, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));

        LinearLayout toggle = UI.row(c);
        toggle.setBackground(UI.box(c, UI.CARD, 16, UI.BORDER, 1));
        toggle.setPadding(UI.dp(c, 6), UI.dp(c, 6), UI.dp(c, 6), UI.dp(c, 6));

        LinearLayout sellBtn = UI.row(c);
        sellBtn.setGravity(Gravity.CENTER);
        sellBtn.setBackground(UI.clickable(c, UI.PRIMARY, 12, 0, 0));
        sellBtn.setPadding(UI.dp(c, 8), UI.dp(c, 12), UI.dp(c, 8), UI.dp(c, 12));
        sellBtn.addView(UI.icon(c, Icons.NORTH_EAST, UI.WHITE, 16));
        sellBtn.addView(UI.hs(c, 6));
        LinearLayout sellTexts = UI.col(c);
        sellTexts.addView(UI.tv(c, isBn() ? "বিক্রি করুন" : "Sell USD", 13, UI.WHITE, true));
        sellTexts.addView(UI.tv(c, isBn() ? "আমি ডলার বিক্রি করব" : "I want to sell USD",
                8, UI.WHITE70, false));
        sellBtn.addView(sellTexts, UI.lp(UI.WRAP, UI.WRAP));
        sellBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAdminListScreen();
            }
        });
        toggle.addView(sellBtn, UI.lpw(0, UI.WRAP, 1f));
        toggle.addView(UI.hs(c, 6));

        LinearLayout buyBtn = UI.row(c);
        buyBtn.setGravity(Gravity.CENTER);
        buyBtn.setBackground(UI.clickable(c, 0, 12, 0, 0));
        buyBtn.setPadding(UI.dp(c, 8), UI.dp(c, 12), UI.dp(c, 8), UI.dp(c, 12));
        buyBtn.addView(UI.icon(c, Icons.SOUTH_WEST, UI.GREY, 16));
        buyBtn.addView(UI.hs(c, 6));
        LinearLayout buyTexts = UI.col(c);
        buyTexts.addView(UI.tv(c, isBn() ? "কিনুন" : "Buy USD", 13, UI.WHITE, true));
        buyTexts.addView(UI.tv(c, isBn() ? "আমি ডলার কিনব" : "I want to buy USD",
                8, UI.GREY, false));
        buyBtn.addView(buyTexts, UI.lp(UI.WRAP, UI.WRAP));
        buyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBuyUsdScreen();
            }
        });
        toggle.addView(buyBtn, UI.lpw(0, UI.WRAP, 1f));
        page.addView(toggle, UI.lp(UI.MATCH, UI.WRAP));
        page.addView(UI.vs(c, 14));

        LinearLayout rateCard = UI.col(c);
        rateCard.setBackground(UI.box(c, UI.CARD, 16, UI.BORDER, 1));
        rateCard.setPadding(UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16));

        LinearLayout rateHeader = UI.row(c);
        rateHeader.addView(UI.icon(c, Icons.BAR_CHART, UI.GREEN_ACCENT, 18));
        rateHeader.addView(UI.hs(c, 6));
        rateHeader.addView(UI.tv(c, !rateTitle.isEmpty() ? rateTitle : (isBn() ? "আজকের ডলারের রেট" : "Today's USD Rate"),
                14, UI.WHITE, true));
        rateHeader.addView(UI.flex(c));

        LinearLayout updated = UI.row(c);
        updated.setBackground(UI.box(c, UI.alpha(UI.TEAL, 0.2f), 4, 0, 0));
        updated.setPadding(UI.dp(c, 6), UI.dp(c, 2), UI.dp(c, 6), UI.dp(c, 2));
        updated.addView(UI.icon(c, Icons.SYNC, UI.TEAL_ACCENT, 10));
        updated.addView(UI.hs(c, 4));
        updated.addView(UI.tv(c, isBn() ? "আপডেট হয়েছে" : "Updated", 9, UI.TEAL_ACCENT, false));
        rateHeader.addView(updated, UI.lp(UI.WRAP, UI.WRAP));
        rateCard.addView(rateHeader, UI.lp(UI.MATCH, UI.WRAP));
        rateCard.addView(UI.vs(c, 14));

        TextView rateText = UI.tv(c, ownerRate > 0 ? "1 USD = ৳ " + fmt(ownerRate) : "1 USD = —", 22, UI.YELLOW, true);
        rateCard.addView(rateText, UI.centered(c, 0));
        rateCard.addView(UI.vs(c, 14));

        LinearLayout converter = UI.row(c);
        converter.setBackground(UI.box(c, UI.BG, 10, UI.BORDER, 1));
        converter.setPadding(UI.dp(c, 12), UI.dp(c, 8), UI.dp(c, 12), UI.dp(c, 8));

        LinearLayout usdCol = UI.col(c);
        usdCol.addView(UI.tv(c, isBn() ? "ডলার পরিমাণ লিখুন" : "Enter USD Amount", 9, UI.GREY, false));
        LinearLayout usdRow = UI.row(c);
        usdRow.addView(UI.tv(c, "🇺🇸 ", 14, UI.WHITE, false));
        EditText usdField = new EditText(c);
        usdField.setBackground(null);
        usdField.setMinHeight(0);
        usdField.setMinimumHeight(0);
        usdField.setPadding(0, 0, 0, 0);
        usdField.setSingleLine(true);
        usdField.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        usdField.setTextSize(14);
        usdField.setTextColor(UI.WHITE);
        usdField.setTypeface(usdField.getTypeface(), android.graphics.Typeface.BOLD);
        usdField.setText(usdText);
        usdRow.addView(usdField, UI.lpw(0, UI.WRAP, 1f));
        usdCol.addView(usdRow, UI.lp(UI.MATCH, UI.WRAP));
        converter.addView(usdCol, UI.lpw(0, UI.WRAP, 1f));

        converter.addView(UI.icon(c, Icons.SWAP_HORIZ, UI.GREY, 24));

        LinearLayout bdtCol = UI.col(c);
        TextView bdtLabel = UI.tv(c, isBn() ? "বাংলা টাকায় পরিমাণ" : "Amount in BDT", 9, UI.GREY, false);
        bdtLabel.setGravity(Gravity.END);
        bdtCol.addView(bdtLabel, UI.lp(UI.MATCH, UI.WRAP));
        LinearLayout bdtRow = UI.row(c);
        bdtRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bdtRow.addView(UI.tv(c, "🇧🇩 ", 14, UI.WHITE, false));
        final TextView bdtValue = UI.tv(c, fmt(usdInput * ownerRate), 14, UI.WHITE, true);
        bdtRow.addView(bdtValue, UI.lp(UI.WRAP, UI.WRAP));
        bdtCol.addView(bdtRow, UI.lp(UI.MATCH, UI.WRAP));
        converter.addView(bdtCol, UI.lpw(0, UI.WRAP, 1f));

        usdField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                usdText = s.toString();
                usdInput = parseDouble(usdText);
                bdtValue.setText(fmt(usdInput * ownerRate));
            }
        });
        rateCard.addView(converter, UI.lp(UI.MATCH, UI.WRAP));
        page.addView(rateCard, UI.lp(UI.MATCH, UI.WRAP));
        page.addView(UI.vs(c, 12));

        page.addView(buildInfoTile(Icons.ASSIGNMENT,
                isBn() ? "ডলার তুলতে কি কি লাগে?" : "What is required to withdraw USD?",
                isBn() ? "প্রয়োজনীয় তথ্য ও সম্পূর্ণ বিবরণ দেখুন" : "See details & requirement checklist",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showRequirementDialog();
                    }
                }), UI.lp(UI.MATCH, UI.WRAP));
        page.addView(UI.vs(c, 10));

        page.addView(buildInfoTile(Icons.SHIELD,
                isBn() ? "নিরাপদ ও নির্ভরযোগ্য লেনদেন" : "100% Safe & Secure Transaction",
                isBn() ? "আমাদের সাথে আপনার লেনদেন ১০০% নিরাপদ" : "Your transaction is 100% safe with us",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showSecurityDialog();
                    }
                }), UI.lp(UI.MATCH, UI.WRAP));

        return scroll;
    }

    private String fmt(double v) {
        return String.format(Locale.US, "%.2f", v);
    }

    private double parseDouble(String s) {
        try {
            return Double.parseDouble(s.trim());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private View buildInfoTile(String iconPath, String title, String subtitle,
                               View.OnClickListener onTap) {
        Context c = this;
        LinearLayout tile = UI.row(c);
        tile.setBackground(UI.clickable(c, UI.CARD, 14, UI.BORDER, 1));
        tile.setPadding(UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14));

        FrameLayout iconBox = new FrameLayout(c);
        iconBox.setBackground(UI.box(c, UI.BORDER, 8, 0, 0));
        iconBox.setPadding(UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8));
        iconBox.addView(UI.icon(c, iconPath, UI.BLUE_ACCENT, 20));
        tile.addView(iconBox, UI.lp(UI.WRAP, UI.WRAP));
        tile.addView(UI.hs(c, 12));

        LinearLayout texts = UI.col(c);
        texts.addView(UI.tv(c, title, 13, UI.WHITE, true));
        texts.addView(UI.vs(c, 2));
        texts.addView(UI.tv(c, subtitle, 10, UI.GREY, false));
        tile.addView(texts, UI.lpw(0, UI.WRAP, 1f));

        tile.addView(UI.icon(c, Icons.CHEVRON_RIGHT, UI.GREY, 24));
        tile.setOnClickListener(onTap);
        return tile;
    }

    private void openAdminListScreen() {
        Intent i = new Intent(this, AdminListActivity.class);
        i.putExtra("ownerRate", ownerRate);
        i.putExtra("userId", userId);
        i.putExtra("isBn", isBn());
        startActivity(i);
    }

    private void openBuyUsdScreen() {
        Intent i = new Intent(this, BuyUsdActivity.class);
        i.putExtra("ownerRate", ownerRate);
        i.putExtra("userId", userId);
        i.putExtra("isBn", isBn());
        startActivity(i);
    }

    private void showInfoDialog(String iconPath, int iconColor, float iconSize, float closeSize,
                                String title, float titleSize, String body, float lineSpacing) {
        Context c = this;
        Dialog d = UI.newDialog(c);
        LinearLayout card = UI.dialogCard(c);
        card.addView(UI.closeRow(c, d, closeSize));
        card.addView(UI.icon(c, iconPath, iconColor, iconSize), UI.centered(c, 0));
        card.addView(UI.vs(c, 10));

        TextView t = UI.tv(c, title, titleSize, UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        card.addView(t, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 12));

        TextView b = UI.tv(c, body, 11, UI.GREY, false);
        b.setLineSpacing(0, lineSpacing);
        card.addView(b, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 10));
        UI.showCard(d, card);
    }

    private void showRequirementDialog() {
        showInfoDialog(Icons.ASSIGNMENT, UI.AMBER, 30, 20,
                isBn() ? "ডলার তুলতে কি কি লাগে?" : "Withdrawal Requirements", 16,
                isBn()
                        ? "১. CapCut অ্যাকাউন্টের বিবরণ ও সঠিক আইডি তথ্য।\n"
                        + "২. সর্বনিম্ন ৫ USD ব্যালেন্স থাকতে হবে।\n"
                        + "৩. টাকা গ্রহণের জন্য আপনার সচল বিকাশ, নগদ বা ব্যাংক অ্যাকাউন্ট নম্বর।\n"
                        + "৪. এডমিনের সাথে চ্যাটে সঠিক অ্যাকাউন্টের তথ্য সেন্ড করতে হবে।"
                        : "1. CapCut Account Details & Valid ID Info.\n"
                        + "2. Minimum $5 USD balance in account.\n"
                        + "3. Active bKash, Nagad or Bank account to receive funds.\n"
                        + "4. Send correct account information in Admin Chat.",
                1.25f);
    }

    private void showSecurityDialog() {
        showInfoDialog(Icons.SHIELD, UI.LIGHT_BLUE_ACCENT, 30, 20,
                isBn() ? "১০০% নিরাপদ ও নির্ভরযোগ্য লেনদেন" : "100% Safe & Secure Transaction", 15,
                isBn()
                        ? "আমাদের প্ল্যাটফর্মে সকল এডমিন বিশ্বস্ত। আপনার লেনদেন শতভাগ নিরাপদ।\n\n"
                        + "বিজ্ঞপ্তি: কোনো এডমিন যদি আপনার সাথে খারাপ আচরণ করে বা টাকা প্রদানে দেরি করে, তবে সাথে সাথে সাপোর্ট (Support) অপশনে ক্লিক করে ওনারের সাথে যোগাযোগ করুন।"
                        : "All admins on our platform are verified and trusted. Your transactions are 100% secured.\n\n"
                        + "Notice: If any admin misbehaves or delays payout, contact the Owner immediately via Support.",
                1.2f);
    }

    private void showPrivacyPolicyDialog() {
        Context c = this;
        Dialog d = UI.newDialog(c);
        LinearLayout card = UI.dialogCard(c);
        card.addView(UI.closeRow(c, d, 18));
        card.addView(UI.icon(c, Icons.SECURITY, UI.AMBER, 30), UI.centered(c, 0));
        card.addView(UI.vs(c, 8));

        TextView t = UI.tv(c, isBn() ? "প্রাইভেসি পলিসি" : "Privacy Policy", 16, UI.WHITE, true);
        t.setGravity(Gravity.CENTER);
        card.addView(t, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 10));

        ScrollView sv = new ScrollView(c);
        TextView b = UI.tv(c, isBn()
                ? "১. আমরা আপনার ব্যক্তিগত তথ্যের সর্বোচ্চ গোপনীয়তা রক্ষা করি।\n"
                + "২. আপনার প্রদত্ত সকল লেনদেনের তথ্য এনক্রিপ্ট করে সুরক্ষিত রাখা হয়।\n"
                + "৩. থার্ড-পার্টি কারও সাথে তথ্য শেয়ার করা হয় না।\n"
                + "৪. অ্যাপ ব্যবহারের সাথে সাথেই আপনি আমাদের সকল পলিসি মেনে নিচ্ছেন।"
                : "1. We respect and protect your personal data privacy.\n"
                + "2. All transaction data submitted is stored with high-level encryption.\n"
                + "3. We do not share data with any 3rd-party entities.\n"
                + "4. By using this app, you agree to our policies.",
                11, UI.GREY, false);
        b.setLineSpacing(0, 1.25f);
        sv.addView(b, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));
        card.addView(sv, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 12));
        UI.showCard(d, card);
    }

    private View buildUpdateTab() {
        final Context c = this;
        LinearLayout page = UI.col(c);
        page.setPadding(UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16));

        LinearLayout header = UI.row(c);
        header.addView(UI.icon(c, Icons.CAMPAIGN, UI.RED_ACCENT, 20));
        header.addView(UI.hs(c, 8));
        header.addView(UI.tv(c, isBn() ? "Capcut লেটেস্ট আপডেট" : "Capcut Latest Updates",
                15, UI.WHITE, true));
        page.addView(header, UI.lp(UI.MATCH, UI.WRAP));
        page.addView(UI.vs(c, 14));

        LinearLayout card = UI.col(c);
        card.setBackground(UI.box(c, UI.CARD, 14, UI.BORDER, 1));
        card.setPadding(UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14));
        if (updateNotice.isEmpty() && noticeLink.isEmpty()) {
            card.addView(UI.tv(c, isBn() ? "এখনো কোনো নতুন আপডেট নেই।" : "No updates yet.", 12, UI.GREY, false));
        } else {
            card.addView(UI.tv(c, updateNotice, 13, UI.WHITE, true));
            if (!noticeLink.isEmpty()) {
                card.addView(UI.vs(c, 12));
                TextView more = UI.tv(c, isBn() ? "আরও দেখুন" : "View more", 12, UI.BLUE_ACCENT, true);
                more.setPaintFlags(more.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
                more.setPadding(0, UI.dp(c, 4), UI.dp(c, 12), UI.dp(c, 4));
                more.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openLink(noticeLink);
                    }
                });
                card.addView(more, UI.lp(UI.WRAP, UI.WRAP));
            }
        }
        page.addView(card, UI.lp(UI.MATCH, UI.WRAP));
        return page;
    }

    private View buildSupportTab() {
        if (supportChat == null) {
            supportChat = new ChatView(this, userId, isBn(), null);
        } else {
            supportChat.setBn(isBn());
        }
        if (supportChat.getParent() instanceof ViewGroup) {
            ((ViewGroup) supportChat.getParent()).removeView(supportChat);
        }
        FrameLayout holder = new FrameLayout(this);
        holder.setPadding(UI.dp(this, 8), UI.dp(this, 8), UI.dp(this, 8), UI.dp(this, 8));
        holder.addView(supportChat, new FrameLayout.LayoutParams(UI.MATCH, UI.MATCH));
        return holder;
    }

    private View buildProfileTab() {
        Context c = this;
        LinearLayout col = UI.col(c);
        col.setGravity(Gravity.CENTER);

        FrameLayout avatar = new FrameLayout(c);
        avatar.setBackground(UI.oval(UI.BORDER, 0, 0));
        avatar.addView(UI.icon(c, Icons.PERSON, UI.BLUE_ACCENT, 50),
                new FrameLayout.LayoutParams(UI.WRAP, UI.WRAP, Gravity.CENTER));
        col.addView(avatar, UI.lp(UI.dp(c, 80), UI.dp(c, 80)));
        col.addView(UI.vs(c, 12));
        TextView idText = UI.tv(c, (isBn() ? "ইউজার আইডি" : "User ID") + ": " + userId,
                16, UI.WHITE, true);
        idText.setGravity(Gravity.CENTER);
        col.addView(idText, UI.lp(UI.MATCH, UI.WRAP));
        return col;
    }

    private void showSettingsDialog() {
        final Context c = this;
        final Dialog d = UI.newDialog(c);
        final FrameLayout holder = new FrameLayout(c);
        fillSettings(d, holder);
        UI.showCard(d, holder);
    }

    private void fillSettings(final Dialog d, final FrameLayout holder) {
        final Context c = this;
        holder.removeAllViews();

        LinearLayout card = UI.dialogCard(c);
        card.addView(UI.closeRow(c, d, 18));
        card.addView(UI.icon(c, Icons.SETTINGS, UI.BLUE_ACCENT, 28), UI.centered(c, 0));
        card.addView(UI.vs(c, 6));

        TextView title = UI.tv(c, isBn() ? "সেটিংস" : "Settings", 15, UI.WHITE, true);
        title.setGravity(Gravity.CENTER);
        card.addView(title, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 14));

        LinearLayout privacy = UI.row(c);
        privacy.setBackground(UI.clickable(c, UI.BORDER, 10, 0, 0));
        privacy.setPadding(UI.dp(c, 12), UI.dp(c, 10), UI.dp(c, 12), UI.dp(c, 10));
        privacy.addView(UI.icon(c, Icons.LOCK, UI.AMBER, 16));
        privacy.addView(UI.hs(c, 8));
        privacy.addView(UI.tv(c, isBn() ? "প্রাইভেসি পলিসি" : "Privacy Policy", 12, UI.WHITE, false));
        privacy.addView(UI.flex(c));
        privacy.addView(UI.icon(c, Icons.CHEVRON_RIGHT, UI.GREY, 16));
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
                showPrivacyPolicyDialog();
            }
        });
        card.addView(privacy, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 12));

        card.addView(UI.tv(c, isBn() ? "ভাষা পরিবর্তন করুন / Change Language" : "Change Language",
                9, UI.GREY, false));
        card.addView(UI.vs(c, 6));

        LinearLayout langRow = UI.row(c);
        langRow.addView(langButton("বাংলা", isBn(), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeLanguage("bn");
                fillSettings(d, holder);
            }
        }), UI.lpw(0, UI.dp(c, 40), 1f));
        langRow.addView(UI.hs(c, 8));
        langRow.addView(langButton("English", !isBn(), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeLanguage("en");
                fillSettings(d, holder);
            }
        }), UI.lpw(0, UI.dp(c, 40), 1f));
        card.addView(langRow, UI.lp(UI.MATCH, UI.WRAP));

        holder.addView(card, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));
    }

    private View langButton(String text, boolean selected, View.OnClickListener l) {
        Context c = this;
        TextView b = UI.tv(c, text, 11, UI.WHITE, false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(UI.clickable(c, selected ? UI.PRIMARY : UI.BORDER, 20, 0, 0));
        b.setOnClickListener(l);
        return b;
    }
}
