package com.mr.wallet;

import android.app.Application;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        IntegrityGuard.install(this);
    }
}
