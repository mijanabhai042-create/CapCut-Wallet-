package com.mr.wallet;

import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

final class AdminInfo {
    String id = "";
    String name = "Admin";
    String img = "";
    double rate = 0.0;
    String minUsd = "";
    String maxUsd = "";
    String countries = "";
    final List<String> methods = new ArrayList<>();

    void putTo(Intent i) {
        i.putExtra("adminId", id);
        i.putExtra("adminName", name);
        i.putExtra("adminImg", img);
        i.putExtra("adminRate", rate);
        i.putStringArrayListExtra("adminMethods", new ArrayList<>(methods));
    }

    static AdminInfo from(Intent i) {
        AdminInfo a = new AdminInfo();
        a.id = nz(i.getStringExtra("adminId"));
        a.name = i.getStringExtra("adminName") == null ? "Admin" : i.getStringExtra("adminName");
        a.img = nz(i.getStringExtra("adminImg"));
        a.rate = i.getDoubleExtra("adminRate", 0.0);
        List<String> m = i.getStringArrayListExtra("adminMethods");
        if (m != null) a.methods.addAll(m);
        return a;
    }

    private static String nz(String s) { return s == null ? "" : s; }
}
