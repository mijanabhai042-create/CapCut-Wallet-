package com.mr.wallet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(i.getAction())) {
            try { ContextCompat.startForegroundService(c, new Intent(c, NotifyService.class)); }
            catch (Exception ignored) { }
        }
    }
}
