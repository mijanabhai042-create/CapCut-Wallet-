package com.mr.wallet;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

final class UI {
    private UI() {}

    static final int BG = 0xFF030712;
    static final int APPBAR = 0xFF070D19;
    static final int CARD = 0xFF0B132B;
    static final int BORDER = 0xFF1E293B;
    static final int PRIMARY = 0xFF2563EB;
    static final int SKY = 0xFF38BDF8;
    static final int YELLOW = 0xFFFACC15;
    static final int GREEN_DOT = 0xFF22C55E;
    static final int EMERALD = 0xFF10B981;

    static final int WHITE = 0xFFFFFFFF;
    static final int WHITE70 = 0xB3FFFFFF;
    static final int BLACK = 0xFF000000;
    static final int GREY = 0xFF9E9E9E;
    static final int AMBER = 0xFFFFC107;
    static final int BLUE_ACCENT = 0xFF448AFF;
    static final int GREEN_ACCENT = 0xFF69F0AE;
    static final int TEAL_ACCENT = 0xFF64FFDA;
    static final int TEAL = 0xFF009688;
    static final int RED = 0xFFF44336;
    static final int RED_ACCENT = 0xFFFF5252;
    static final int LIGHT_BLUE_ACCENT = 0xFF40C4FF;
    static final int CYAN = 0xFF00BCD4;
    static final int PINK = 0xFFE91E63;
    static final int ORANGE = 0xFFFF9800;
    static final int BLUE = 0xFF2196F3;
    static final int GREEN = 0xFF4CAF50;

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static int alpha(int color, float a) {
        return (Math.round(a * 255) << 24) | (color & 0x00FFFFFF);
    }

    static GradientDrawable box(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) {
            d.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        }
        return d;
    }

    static GradientDrawable oval(int fill, int stroke, int strokePx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(fill);
        if (stroke != 0) d.setStroke(strokePx, stroke);
        return d;
    }

    static Drawable clickable(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        Drawable content = box(c, fill, radiusDp, stroke, strokeDp);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(Color.WHITE);
        mask.setCornerRadius(dp(c, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask);
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams lpw(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams lpm(Context c, int w, int h, float l, float t, float r, float b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static View vs(Context c, float hDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, dp(c, hDp)));
        return v;
    }

    static View hs(Context c, float wDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, wDp), 0));
        return v;
    }

    static View flex(Context c) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 0, 1f));
        return v;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static TextView tv(Context c, String text, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    static IconView icon(Context c, String pathData, int color, float sizeDp) {
        return new IconView(c, pathData, color, sizeDp);
    }

    static FrameLayout iconButton(Context c, String pathData, int color, float iconDp,
                                  View.OnClickListener l) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(clickable(c, 0, 24, 0, 0));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER);
        f.addView(icon(c, pathData, color, iconDp), p);
        f.setOnClickListener(l);
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 48), dp(c, 48)));
        return f;
    }

    static LinearLayout appBar(final Activity a, View titleView) {
        LinearLayout bar = row(a);
        bar.setBackgroundColor(APPBAR);
        bar.setPadding(dp(a, 4), 0, dp(a, 8), 0);
        bar.addView(iconButton(a, Icons.ARROW_BACK, WHITE, 24, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a.finish();
            }
        }));
        bar.addView(hs(a, 8));
        bar.addView(titleView, lpw(0, WRAP, 1f));
        bar.setLayoutParams(new LinearLayout.LayoutParams(MATCH, dp(a, 56)));
        return bar;
    }

    static void copyToClipboard(Context c, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("text", text));
    }

    static void snack(View anchor, String msg, int bg, int duration) {
        Snackbar sb = Snackbar.make(anchor, msg, duration);
        if (bg != 0) {
            sb.setBackgroundTint(bg);
            sb.setTextColor(WHITE);
        }
        sb.show();
    }

    static Dialog newDialog(Context c) {
        Dialog d = new Dialog(c);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        return d;
    }

    static LinearLayout dialogCard(Context c) {
        LinearLayout card = col(c);
        card.setBackground(box(c, CARD, 16, 0, 0));
        card.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16));
        return card;
    }

    static void showCard(Dialog d, View card) {
        Context c = card.getContext();
        FrameLayout root = new FrameLayout(c);
        root.addView(card, new FrameLayout.LayoutParams(MATCH, WRAP));
        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), dp(c, 24), 0, dp(c, 24), 0));
            w.setLayout(MATCH, WRAP);
        }
        d.show();
    }

    static View closeRow(Context c, final Dialog d, float sizeDp) {
        LinearLayout r = new LinearLayout(c);
        r.setGravity(Gravity.END);
        FrameLayout f = new FrameLayout(c);
        f.setPadding(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4));
        f.addView(icon(c, Icons.CLOSE, GREY, sizeDp));
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        r.addView(f, lp(WRAP, WRAP));
        r.setLayoutParams(new LinearLayout.LayoutParams(MATCH, WRAP));
        return r;
    }

    static LinearLayout.LayoutParams centered(Context c, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(WRAP, WRAP);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        p.topMargin = dp(c, topDp);
        return p;
    }
}
