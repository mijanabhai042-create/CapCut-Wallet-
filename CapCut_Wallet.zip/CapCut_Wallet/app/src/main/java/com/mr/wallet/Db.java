package com.mr.wallet;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;

import java.util.HashMap;
import java.util.Map;

public final class Db {
    private Db() {}

    public static final String DB_URL = "https://capcut-master-default-rtdb.firebaseio.com";

    private static FirebaseDatabase inst;

    public static synchronized FirebaseDatabase get() {
        if (inst == null) {
            inst = FirebaseDatabase.getInstance(DB_URL);
        }
        return inst;
    }

    public static DatabaseReference root() { return get().getReference(); }
    public static DatabaseReference ref(String path) { return get().getReference(path); }

    public static void notifyUser(String recipientId, String title, String body, String chat) {
        if (recipientId == null || recipientId.isEmpty()) return;
        Map<String, Object> m = new HashMap<>();
        m.put("title", title);
        m.put("body", body);
        m.put("chat", chat == null ? "" : chat);
        m.put("ts", ServerValue.TIMESTAMP);
        ref("notifications").child(recipientId).push().setValue(m);
    }
}
