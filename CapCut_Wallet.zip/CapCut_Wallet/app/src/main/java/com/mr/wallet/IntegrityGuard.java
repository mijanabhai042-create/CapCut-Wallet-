package com.mr.wallet;

import android.app.Activity;
import android.app.Application;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;
import android.os.Debug;
import android.os.Process;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileReader;
import java.security.MessageDigest;

public final class IntegrityGuard {
    private IntegrityGuard() {}

    public static final String EXPECTED_SIGNATURE = "";

    public static void install(Application app) {
        if (isDebuggableBuild(app)) return;
        app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, android.os.Bundle b) { verify(a); }
            @Override public void onActivityStarted(Activity a) { }
            @Override public void onActivityResumed(Activity a) { }
            @Override public void onActivityPaused(Activity a) { }
            @Override public void onActivityStopped(Activity a) { }
            @Override public void onActivitySaveInstanceState(Activity a, android.os.Bundle b) { }
            @Override public void onActivityDestroyed(Activity a) { }
        });
    }

    private static boolean isDebuggableBuild(Application app) {
        return (app.getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
    }

    private static void verify(Activity a) {
        String problem = null;
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) problem = "debugger";
        else if (hooked()) problem = "hook";
        else if (!signatureOk(a)) problem = "signature";
        if (problem != null) {
            try { Toast.makeText(a, "Security violation. Install the original app.", Toast.LENGTH_LONG).show(); }
            catch (Exception ignored) { }
            a.finishAffinity();
            Process.killProcess(Process.myPid());
            System.exit(1);
        }
    }

    private static boolean hooked() {
        try { Class.forName("de.robv.android.xposed.XposedBridge"); return true; } catch (Throwable ignored) { }
        try {
            BufferedReader r = new BufferedReader(new FileReader("/proc/self/maps"));
            String line;
            while ((line = r.readLine()) != null) {
                String l = line.toLowerCase();
                if (l.contains("frida") || l.contains("xposed") || l.contains("libsubstrate") || l.contains("lsposed")) {
                    r.close();
                    return true;
                }
            }
            r.close();
        } catch (Throwable ignored) { }
        return false;
    }

    private static boolean signatureOk(Activity a) {
        if (EXPECTED_SIGNATURE.isEmpty()) return true;
        try {
            PackageManager pm = a.getPackageManager();
            Signature[] sigs;
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo pi = pm.getPackageInfo(a.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                SigningInfo si = pi.signingInfo;
                if (si == null) return false;
                sigs = si.hasMultipleSigners() ? si.getApkContentsSigners() : si.getSigningCertificateHistory();
            } else {
                PackageInfo pi = pm.getPackageInfo(a.getPackageName(), PackageManager.GET_SIGNATURES);
                sigs = pi.signatures;
            }
            if (sigs == null || sigs.length == 0) return false;
            for (Signature s : sigs) {
                byte[] d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray());
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b));
                if (sb.toString().equalsIgnoreCase(EXPECTED_SIGNATURE.replace(":", ""))) return true;
            }
            return false;
        } catch (Throwable t) {
            return false;
        }
    }
}
