package com.mr.wallet;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

import androidx.core.graphics.PathParser;

final class IconView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path src;
    private final Path dst = new Path();
    private final Matrix matrix = new Matrix();
    private final int sizePx;

    IconView(Context c, String pathData, int color, float sizeDp) {
        super(c);
        sizePx = UI.dp(c, sizeDp);
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        Path p;
        try {
            p = PathParser.createPathFromPathData(pathData);
        } catch (RuntimeException e) {
            p = null;
        }
        src = p != null ? p : new Path();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(sizePx, sizePx);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float s = getWidth() / 24f;
        matrix.reset();
        matrix.setScale(s, s);
        src.transform(matrix, dst);
        canvas.drawPath(dst, paint);
    }
}
