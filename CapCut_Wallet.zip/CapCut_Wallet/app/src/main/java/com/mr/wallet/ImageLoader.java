package com.mr.wallet;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    private ImageLoader() {}

    private static final LruCache<String, Bitmap> CACHE = new LruCache<>(30);
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void load(final String url, final ImageView target) {
        target.setTag(url);
        if (url == null || url.isEmpty()) return;
        if (url.startsWith("data:")) {
            try {
                String b64 = url.substring(url.indexOf(',') + 1);
                byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                Bitmap b = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (b != null) target.setImageBitmap(b);
            } catch (Exception ignored) { }
            return;
        }
        Bitmap cached = CACHE.get(url);
        if (cached != null) {
            target.setImageBitmap(cached);
            return;
        }
        POOL.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                InputStream in = null;
                try {
                    conn = (HttpURLConnection) new URL(url).openConnection();
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(8000);
                    conn.setInstanceFollowRedirects(true);
                    in = conn.getInputStream();
                    final Bitmap bmp = BitmapFactory.decodeStream(in);
                    if (bmp != null) {
                        CACHE.put(url, bmp);
                        MAIN.post(new Runnable() {
                            @Override
                            public void run() {
                                if (url.equals(target.getTag())) {
                                    target.setImageBitmap(bmp);
                                }
                            }
                        });
                    }
                } catch (Exception ignored) {
                } finally {
                    try {
                        if (in != null) in.close();
                    } catch (Exception ignored) {
                    }
                    if (conn != null) conn.disconnect();
                }
            }
        });
    }
}
