package com.mr.wallet;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ChatView extends LinearLayout {

    static class ChatMessage {
        String id;
        String text;
        boolean isMine;
        long timestamp;
        boolean isEdited;
        String type = "text";   // text | request | paid
        String txId = "";
    }

    private final String userId;
    private final AdminInfo admin;
    private final boolean isOwnerSupport;
    private boolean isBn;

    private final List<ChatMessage> messages = new ArrayList<>();
    private final Map<String, String> txStatus = new HashMap<>();
    private LinearLayout messagesBox;
    private ScrollView scroll;
    private EditText msgInput;
    private String draft = "";

    private DatabaseReference chatRef;
    private Query messagesQuery, txQuery;
    private ValueEventListener messagesListener, txListener;
    private boolean attached = false;

    public ChatView(Context context, String userId, boolean isBn, @Nullable AdminInfo admin) {
        super(context);
        this.userId = userId;
        this.admin = admin;
        this.isOwnerSupport = admin == null;
        this.isBn = isBn;
        setOrientation(VERTICAL);
        chatRef = isOwnerSupport
                ? Db.ref("chats").child(userId)
                : Db.ref("admin_chats").child(admin.id).child(userId);
        buildUi();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (attached) return;
        attached = true;
        if (isOwnerSupport) Notifier.activeChat = "owner";

        messagesQuery = chatRef.child("messages").orderByChild("timestamp").limitToLast(300);
        messagesListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                messages.clear();
                for (DataSnapshot c : s.getChildren()) {
                    ChatMessage m = new ChatMessage();
                    m.id = c.getKey();
                    m.text = val(c, "text");
                    m.timestamp = num(c, "timestamp");
                    if (m.timestamp > 0 && m.timestamp < System.currentTimeMillis() - 48L * 60 * 60 * 1000) {
                        c.getRef().removeValue();
                        continue;
                    }
                    m.isEdited = Boolean.TRUE.equals(c.child("isEdited").getValue());
                    String t = val(c, "type");
                    m.type = t.isEmpty() ? "text" : t;
                    m.txId = val(c, "txId");
                    String sender = val(c, "sender");
                    boolean isOwnerMsg = Boolean.TRUE.equals(c.child("isOwner").getValue());
                    m.isMine = sender.isEmpty() ? !isOwnerMsg : sender.equals("user");
                    messages.add(m);
                }
                renderMessages();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError e) {
                toast("ত্রুটি: " + e.getMessage());
            }
        };
        messagesQuery.addValueEventListener(messagesListener);

        if (!isOwnerSupport) {
            txQuery = Db.ref("transactions").orderByChild("userId").equalTo(userId);
            txListener = new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot s) {
                    txStatus.clear();
                    for (DataSnapshot c : s.getChildren()) txStatus.put(c.getKey(), val(c, "status"));
                    renderMessages();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError e) { }
            };
            txQuery.addValueEventListener(txListener);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (!attached) return;
        attached = false;
        if (messagesQuery != null && messagesListener != null) messagesQuery.removeEventListener(messagesListener);
        if (txQuery != null && txListener != null) txQuery.removeEventListener(txListener);
        if (isOwnerSupport && "owner".equals(Notifier.activeChat)) Notifier.activeChat = "";
    }

    private static String val(DataSnapshot s, String k) {
        Object v = s.child(k).getValue();
        return v == null ? "" : String.valueOf(v);
    }

    private static long num(DataSnapshot s, String k) {
        Object v = s.child(k).getValue();
        return (v instanceof Number) ? ((Number) v).longValue() : 0L;
    }

    private void toast(String m) {
        Toast.makeText(getContext(), m, Toast.LENGTH_SHORT).show();
    }

    public String getUserId() {
        return userId;
    }

    public void setBn(boolean bn) {
        if (this.isBn == bn) return;
        if (msgInput != null) draft = msgInput.getText().toString();
        this.isBn = bn;
        buildUi();
        renderMessages();
    }

    private void buildUi() {
        removeAllViews();
        final Context c = getContext();

        addView(UI.vs(c, 10));
        TextView today = UI.tv(c, isBn ? "আজ" : "Today", 9, UI.GREY, false);
        today.setGravity(Gravity.CENTER);
        addView(today, UI.lp(UI.MATCH, UI.WRAP));
        addView(UI.vs(c, 10));

        scroll = new ScrollView(c);
        messagesBox = UI.col(c);
        messagesBox.setPadding(UI.dp(c, 12), 0, UI.dp(c, 12), 0);
        scroll.addView(messagesBox, new FrameLayout.LayoutParams(UI.MATCH, UI.WRAP));
        addView(scroll, UI.lpw(UI.MATCH, 0, 1f));

        if (!isOwnerSupport) {
            LinearLayout wrap = UI.col(c);
            wrap.setPadding(UI.dp(c, 14), 0, UI.dp(c, 14), 0);

            LinearLayout btn = UI.row(c);
            btn.setBackground(UI.clickable(c, UI.PRIMARY, 10, 0, 0));
            btn.setPadding(UI.dp(c, 16), UI.dp(c, 12), UI.dp(c, 16), UI.dp(c, 12));
            btn.addView(UI.tv(c, isBn ? "+ নতুন ডলার বিক্রির অনুরোধ" : "+ New Sell Request",
                    12, UI.WHITE, true));
            btn.addView(UI.flex(c));
            btn.addView(UI.icon(c, Icons.CHEVRON_RIGHT, UI.WHITE, 18));
            btn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSellRequestModal();
                }
            });
            wrap.addView(btn, UI.lp(UI.MATCH, UI.WRAP));
            addView(wrap, UI.lp(UI.MATCH, UI.WRAP));
        }

        LinearLayout inputBar = UI.row(c);
        inputBar.setBackground(UI.box(c, UI.CARD, 20, 0, 0));
        inputBar.setPadding(UI.dp(c, 10), UI.dp(c, 4), UI.dp(c, 10), UI.dp(c, 4));

        msgInput = new EditText(c);
        msgInput.setBackground(null);
        msgInput.setMinHeight(0);
        msgInput.setMinimumHeight(0);
        msgInput.setPadding(0, UI.dp(c, 10), 0, UI.dp(c, 10));
        msgInput.setSingleLine(true);
        msgInput.setTextSize(11);
        msgInput.setTextColor(UI.WHITE);
        msgInput.setHintTextColor(UI.GREY);
        msgInput.setHint(isBn
                ? (isOwnerSupport ? "ওনারকে মেসেজ লিখুন..." : "মেসেজ লিখুন...")
                : "Write message...");
        msgInput.setText(draft);
        msgInput.setSelection(msgInput.getText().length());
        inputBar.addView(msgInput, UI.lpw(0, UI.WRAP, 1f));
        inputBar.addView(UI.iconButton(c, Icons.SEND, UI.BLUE_ACCENT, 18, new OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage(null);
            }
        }));
        addView(inputBar, UI.lpm(c, UI.MATCH, UI.WRAP, 10, 10, 10, 10));

        renderMessages();
    }

    private void renderMessages() {
        final Context c = getContext();
        messagesBox.removeAllViews();
        if (messages.isEmpty()) {
            TextView hello = UI.tv(c, isOwnerSupport
                    ? (isBn ? "ওনার সাপোর্টে আপনাকে স্বাগতম। আপনার সমস্যাটি লিখে পাঠান।"
                            : "Welcome to Owner Support. Please state your issue.")
                    : (isBn ? "চ্যাট শুরু করুন। ডলার বিক্রির তথ্য দিয়ে নতুন অনুরোধ পাঠান।"
                            : "Start the chat. Send a new sell request with your details."),
                    11, UI.GREY, false);
            hello.setGravity(Gravity.CENTER);
            hello.setPadding(0, UI.dp(c, 30), 0, 0);
            messagesBox.addView(hello, UI.lp(UI.MATCH, UI.WRAP));
        }
        for (final ChatMessage msg : messages) {
            LinearLayout bubble = UI.col(c);
            bubble.setBackground(UI.box(c, msg.isMine ? UI.PRIMARY : UI.CARD, 12, 0, 0));
            bubble.setPadding(UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12));

            TextView text = UI.tv(c, msg.text, 11, UI.WHITE, false);
            bubble.addView(text, UI.lp(UI.WRAP, UI.WRAP));
            bubble.addView(UI.vs(c, 4));
            TextView time = UI.tv(c, formatTime(msg.timestamp, msg.isEdited), 8, UI.GREY, false);
            LinearLayout.LayoutParams tp = UI.lp(UI.WRAP, UI.WRAP);
            tp.gravity = msg.isMine ? Gravity.END : Gravity.START;
            bubble.addView(time, tp);

            if ("paid".equals(msg.type) && !msg.isMine) {
                String st = txStatus.get(msg.txId);
                if ("paid_sent".equals(st)) {
                    final String txId = msg.txId;
                    bubble.addView(UI.vs(c, 8));
                    TextView recv = UI.tv(c, isBn ? "✔ রিসিভ করেছি" : "✔ Received", 12, UI.WHITE, true);
                    recv.setGravity(Gravity.CENTER);
                    recv.setBackground(UI.clickable(c, UI.EMERALD, 8, 0, 0));
                    recv.setPadding(UI.dp(c, 16), UI.dp(c, 10), UI.dp(c, 16), UI.dp(c, 10));
                    recv.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            confirmReceived(txId);
                        }
                    });
                    bubble.addView(recv, UI.lp(UI.MATCH, UI.WRAP));
                } else if ("success".equals(st)) {
                    bubble.addView(UI.vs(c, 6));
                    bubble.addView(UI.tv(c, isBn ? "✅ সফলভাবে রিসিভ করা হয়েছে" : "✅ Received successfully",
                            10, UI.GREEN_ACCENT, true));
                }
            }

            bubble.setOnLongClickListener(new OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showMsgOptions(msg);
                    return true;
                }
            });

            LinearLayout.LayoutParams bp = UI.lpm(c, UI.WRAP, UI.WRAP, 0, 0, 0, 8);
            bp.gravity = msg.isMine ? Gravity.END : Gravity.START;
            messagesBox.addView(bubble, bp);
        }
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    private String formatTime(long ts, boolean edited) {
        long diffMs = System.currentTimeMillis() - ts;
        long inSeconds = diffMs / 1000L;
        long inMinutes = diffMs / 60000L;
        long inHours = diffMs / 3600000L;

        String timeStr;
        if (inSeconds < 60) {
            timeStr = isBn ? "এখন" : "Just now";
        } else if (inMinutes < 60) {
            timeStr = isBn ? inMinutes + " মি আগে" : inMinutes + "m ago";
        } else if (inHours < 24) {
            timeStr = isBn ? inHours + " ঘণ্টা আগে" : inHours + "h ago";
        } else {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(ts);
            timeStr = cal.get(Calendar.HOUR_OF_DAY) + ":"
                    + String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE));
        }

        if (edited) {
            return isBn ? timeStr + " (সম্পাদিত)" : timeStr + " (Edited)";
        }
        return timeStr;
    }

    private String nowLabel() {
        Calendar cal = Calendar.getInstance();
        return cal.get(Calendar.HOUR_OF_DAY) + ":" + String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE));
    }

    private void sendMessage(String customText) {
        sendMessage(customText, "text", "");
    }

    private void sendMessage(String customText, String type, String txId) {
        String textToSend = customText != null ? customText : msgInput.getText().toString().trim();
        if (textToSend.isEmpty()) return;

        String msgId = chatRef.child("messages").push().getKey();
        if (msgId == null) return;
        String now = nowLabel();

        Map<String, Object> msg = new HashMap<>();
        msg.put("id", msgId);
        msg.put("text", textToSend);
        msg.put("sender", "user");
        msg.put("isOwner", false);
        msg.put("type", type);
        if (!txId.isEmpty()) msg.put("txId", txId);
        msg.put("time", now);
        msg.put("timestamp", ServerValue.TIMESTAMP);
        msg.put("isEdited", false);
        chatRef.child("messages").child(msgId).setValue(msg);

        Map<String, Object> last = new HashMap<>();
        last.put("lastMessage", textToSend);
        last.put("lastTime", now);
        last.put("lastTs", ServerValue.TIMESTAMP);
        if (!isOwnerSupport) last.put("userId", userId);
        chatRef.updateChildren(last);

        if (isOwnerSupport) {
            Db.notifyUser("owner", userId, textToSend, userId);
        } else {
            chatRef.child("unread").runTransaction(new Transaction.Handler() {
                @NonNull @Override
                public Transaction.Result doTransaction(@NonNull MutableData d) {
                    Object v = d.getValue();
                    long n = (v instanceof Number) ? ((Number) v).longValue() : 0L;
                    d.setValue(n + 1);
                    return Transaction.success(d);
                }

                @Override
                public void onComplete(@Nullable DatabaseError e, boolean ok, @Nullable DataSnapshot s) { }
            });
            Db.notifyUser(admin.id, userId, textToSend, userId);
        }
        if (customText == null) msgInput.setText("");
    }

    private void confirmReceived(String txId) {
        if (txId == null || txId.isEmpty()) return;
        Map<String, Object> m = new HashMap<>();
        m.put("status", "success");
        m.put("successAt", ServerValue.TIMESTAMP);
        Db.ref("transactions").child(txId).updateChildren(m);
        if (admin != null) {
            Db.notifyUser(admin.id, userId, isBn ? "ইউজার টাকা রিসিভ নিশ্চিত করেছেন ✅" : "User confirmed the payment ✅", userId);
        }
        toast(isBn ? "লেনদেন সফল হয়েছে!" : "Transaction successful!");
    }

    private void editMessage(final ChatMessage msg) {
        final Context c = getContext();
        final Dialog d = UI.newDialog(c);
        LinearLayout card = UI.dialogCard(c);

        card.addView(UI.tv(c, isBn ? "মেসেজ এডিট করুন" : "Edit Message", 14, UI.WHITE, false));
        card.addView(UI.vs(c, 12));

        final EditText edit = new EditText(c);
        edit.setText(msg.text);
        edit.setTextSize(12);
        edit.setTextColor(UI.WHITE);
        edit.setBackgroundTintList(ColorStateList.valueOf(UI.BLUE_ACCENT));
        edit.setSelection(edit.getText().length());
        card.addView(edit, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 16));

        LinearLayout actions = UI.row(c);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);

        TextView cancel = UI.tv(c, isBn ? "বাতিল" : "Cancel", 14, UI.GREY, false);
        cancel.setGravity(Gravity.CENTER);
        cancel.setBackground(UI.clickable(c, 0, 20, 0, 0));
        cancel.setPadding(UI.dp(c, 16), UI.dp(c, 10), UI.dp(c, 16), UI.dp(c, 10));
        cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });
        actions.addView(cancel, UI.lp(UI.WRAP, UI.WRAP));
        actions.addView(UI.hs(c, 8));

        TextView save = UI.tv(c, isBn ? "সেভ করুন" : "Save", 14, UI.WHITE, false);
        save.setGravity(Gravity.CENTER);
        save.setBackground(UI.clickable(c, UI.PRIMARY, 20, 0, 0));
        save.setPadding(UI.dp(c, 16), UI.dp(c, 10), UI.dp(c, 16), UI.dp(c, 10));
        save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = edit.getText().toString().trim();
                if (!t.isEmpty()) {
                    Map<String, Object> upd = new HashMap<>();
                    upd.put("text", t);
                    upd.put("isEdited", true);
                    chatRef.child("messages").child(msg.id).updateChildren(upd);
                }
                d.dismiss();
            }
        });
        actions.addView(save, UI.lp(UI.WRAP, UI.WRAP));
        card.addView(actions, UI.lp(UI.MATCH, UI.WRAP));

        UI.showCard(d, card);
    }

    private void deleteMessage(ChatMessage msg) {
        chatRef.child("messages").child(msg.id).removeValue();
    }

    private View optionRow(String iconPath, int iconColor, String title, OnClickListener l) {
        Context c = getContext();
        LinearLayout r = UI.row(c);
        r.setBackground(UI.clickable(c, 0, 0, 0, 0));
        r.setPadding(UI.dp(c, 16), UI.dp(c, 14), UI.dp(c, 16), UI.dp(c, 14));
        r.addView(UI.icon(c, iconPath, iconColor, 24));
        r.addView(UI.hs(c, 16));
        r.addView(UI.tv(c, title, 16, UI.WHITE, false));
        r.setOnClickListener(l);
        r.setLayoutParams(new LinearLayout.LayoutParams(UI.MATCH, UI.WRAP));
        return r;
    }

    private void showMsgOptions(final ChatMessage msg) {
        final Context c = getContext();
        final BottomSheetDialog sheet = new BottomSheetDialog(c);
        LinearLayout box = UI.col(c);
        box.setBackgroundColor(UI.CARD);

        box.addView(optionRow(Icons.COPY, UI.AMBER,
                isBn ? "মেসেজ কপি করুন" : "Copy Message", new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sheet.dismiss();
                        UI.copyToClipboard(c, msg.text);
                        UI.snack(ChatView.this,
                                isBn ? "মেসেজ কপি করা হয়েছে!" : "Message copied!",
                                0, Snackbar.LENGTH_SHORT);
                    }
                }));

        if (msg.isMine && !"request".equals(msg.type)) {
            box.addView(optionRow(Icons.EDIT, UI.BLUE_ACCENT,
                    isBn ? "মেসেজ এডিট করুন" : "Edit Message", new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            sheet.dismiss();
                            editMessage(msg);
                        }
                    }));
            box.addView(optionRow(Icons.DELETE, UI.RED_ACCENT,
                    isBn ? "মেসেজ ডিলিট করুন" : "Delete Message", new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            sheet.dismiss();
                            deleteMessage(msg);
                        }
                    }));
        }

        sheet.setContentView(box);
        sheet.show();
    }

    private View inputField(String label, EditText input) {
        Context c = getContext();
        LinearLayout col = UI.col(c);
        col.addView(UI.tv(c, label, 9, UI.GREY, false));
        col.addView(UI.vs(c, 4));

        LinearLayout holder = UI.col(c);
        holder.setBackground(UI.box(c, UI.BG, 8, UI.BORDER, 1));
        holder.setPadding(UI.dp(c, 10), UI.dp(c, 8), UI.dp(c, 10), UI.dp(c, 8));
        input.setBackground(null);
        input.setMinHeight(0);
        input.setMinimumHeight(0);
        input.setPadding(0, 0, 0, 0);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setTextSize(11);
        input.setTextColor(UI.WHITE);
        holder.addView(input, UI.lp(UI.MATCH, UI.WRAP));
        col.addView(holder, UI.lp(UI.MATCH, UI.WRAP));
        return col;
    }

    private void showSellRequestModal() {
        final Context c = getContext();

        final String[][] countries = {
                {"🇧🇩", "Bangladesh"},
                {"🇻🇳", "Vietnam"},
                {"🇸🇬", "Singapore"},
                {"🇲🇾", "Malaysia"},
                {"🇦🇺", "Australia"},
                {"🇶🇦", "Qatar"},
                {"🇸🇦", "Saudi Arabia"},
                {"🇦🇪", "United Arab Emirates (Dubai)"},
                {"🇺🇸", "United States (USA)"},
                {"🇬🇧", "United Kingdom (UK)"},
                {"🇩🇪", "Germany"},
                {"🇧🇷", "Brazil"},
                {"🇮🇩", "Indonesia"},
                {"🇵🇭", "Philippines"},
        };

        final Dialog d = UI.newDialog(c);
        LinearLayout card = UI.dialogCard(c);

        card.addView(UI.closeRow(c, d, 18));

        LinearLayout.LayoutParams ip = UI.lp(UI.WRAP, UI.WRAP);
        card.addView(UI.icon(c, Icons.CHAT_BUBBLE, UI.WHITE, 24), ip);
        card.addView(UI.vs(c, 6));
        card.addView(UI.tv(c, isBn ? "চ্যাট অনুরোধ পাঠান" : "Send Chat Request", 15, UI.WHITE, true));
        card.addView(UI.tv(c, isBn
                ? "এডমিনের সাথে চ্যাট শুরু করতে সঠিক তথ্য দিন।"
                : "Fill information correctly to start chat.", 9, UI.GREY, false));
        card.addView(UI.vs(c, 10));

        TextView limit = UI.tv(c, isBn ? "লেনদেন সীমা: সর্বনিম্ন 5 USD"
                : "Transaction Limit: Minimum $5 USD", 9, UI.GREEN_ACCENT, false);
        limit.setBackground(UI.box(c, UI.alpha(UI.GREEN, 0.1f), 6, 0, 0));
        limit.setPadding(UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8), UI.dp(c, 8));
        card.addView(limit, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 10));

        if (admin == null || admin.methods.isEmpty()) {
        }
        final EditText amountInput = new EditText(c);
        amountInput.setText("5");
        final EditText countInput = new EditText(c);
        countInput.setText("1");

        card.addView(inputField(isBn ? "ডলারের পরিমাণ লিখুন" : "Enter USD Amount", amountInput),
                UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 8));
        card.addView(inputField(isBn ? "অ্যাকাউন্টের সংখ্যা লিখুন" : "Enter Account Count", countInput),
                UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 8));

        card.addView(UI.tv(c, isBn ? "অ্যাকাউন্ট কান্ট্রি (CapCut Official)"
                : "Account Country (CapCut Official)", 9, UI.GREY, false));
        card.addView(UI.vs(c, 4));

        List<String> labels = new ArrayList<>();
        for (String[] country : countries) {
            labels.add(country[0] + "  " + country[1]);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(c,
                android.R.layout.simple_spinner_item, labels) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(UI.WHITE);
                t.setTextSize(11);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setPadding(0, UI.dp(c, 10), 0, UI.dp(c, 10));
                return t;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent);
                t.setTextColor(UI.WHITE);
                t.setTextSize(12);
                t.setBackgroundColor(UI.CARD);
                t.setPadding(UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12));
                return t;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        final Spinner spinner = new Spinner(c);
        spinner.setAdapter(adapter);
        spinner.setBackground(null);
        spinner.setPadding(0, 0, 0, 0);
        spinner.setPopupBackgroundDrawable(new ColorDrawable(UI.CARD));

        LinearLayout spinnerRow = UI.row(c);
        spinnerRow.setBackground(UI.box(c, UI.BG, 8, UI.BORDER, 1));
        spinnerRow.setPadding(UI.dp(c, 10), 0, UI.dp(c, 6), 0);
        spinnerRow.addView(spinner, UI.lpw(0, UI.WRAP, 1f));
        spinnerRow.addView(UI.icon(c, Icons.ARROW_DROP_DOWN, UI.GREY, 24));
        spinnerRow.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                spinner.performClick();
            }
        });
        card.addView(spinnerRow, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 14));

        card.addView(UI.tv(c, isBn ? "কোন মাধ্যমে টাকা নিবেন?" : "Receive payment via", 9, UI.GREY, false));
        card.addView(UI.vs(c, 4));
        final List<String> methodList = new ArrayList<>();
        if (admin != null) methodList.addAll(admin.methods);
        if (methodList.isEmpty()) methodList.add("bKash");
        ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(c,
                android.R.layout.simple_spinner_item, methodList) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(UI.WHITE);
                t.setTextSize(11);
                t.setPadding(0, UI.dp(c, 10), 0, UI.dp(c, 10));
                return t;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getDropDownView(position, convertView, parent);
                t.setTextColor(UI.WHITE);
                t.setTextSize(12);
                t.setBackgroundColor(UI.CARD);
                t.setPadding(UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12), UI.dp(c, 12));
                return t;
            }
        };
        mAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        final Spinner methodSpinner = new Spinner(c);
        methodSpinner.setAdapter(mAdapter);
        methodSpinner.setBackground(null);
        methodSpinner.setPopupBackgroundDrawable(new ColorDrawable(UI.CARD));
        LinearLayout methodRow = UI.row(c);
        methodRow.setBackground(UI.box(c, UI.BG, 8, UI.BORDER, 1));
        methodRow.setPadding(UI.dp(c, 10), 0, UI.dp(c, 6), 0);
        methodRow.addView(methodSpinner, UI.lpw(0, UI.WRAP, 1f));
        methodRow.addView(UI.icon(c, Icons.ARROW_DROP_DOWN, UI.GREY, 24));
        methodRow.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                methodSpinner.performClick();
            }
        });
        card.addView(methodRow, UI.lp(UI.MATCH, UI.WRAP));
        card.addView(UI.vs(c, 14));

        LinearLayout send = UI.row(c);
        send.setGravity(Gravity.CENTER);
        send.setBackground(UI.clickable(c, UI.PRIMARY, 8, 0, 0));
        send.setPadding(UI.dp(c, 16), UI.dp(c, 12), UI.dp(c, 16), UI.dp(c, 12));
        send.addView(UI.icon(c, Icons.SEND, UI.WHITE, 14));
        send.addView(UI.hs(c, 8));
        send.addView(UI.tv(c, isBn ? "সেন্ড করুন" : "Send Request", 12, UI.WHITE, true));
        send.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String amt = amountInput.getText().toString().trim();
                String count = countInput.getText().toString().trim();
                double amount;
                try { amount = Double.parseDouble(amt); } catch (Exception e) { amount = 0; }
                if (amount < 5) {
                    toast(isBn ? "সর্বনিম্ন 5 USD দিতে হবে" : "Minimum amount is $5 USD");
                    return;
                }
                if (count.isEmpty() || count.equals("0")) count = "1";
                int pos = spinner.getSelectedItemPosition();
                if (pos < 0) pos = 0;
                String selectedCountry = countries[pos][1];
                String method = methodList.get(Math.max(0, methodSpinner.getSelectedItemPosition()));

                double rate = admin != null ? admin.rate : 0.0;
                double bdt = amount * rate;
                String amtStr = amount == Math.floor(amount)
                        ? String.valueOf((long) amount) : String.format(Locale.US, "%.2f", amount);

                String txId = Db.ref("transactions").push().getKey();
                if (txId != null && admin != null) {
                    Map<String, Object> tx = new HashMap<>();
                    tx.put("userId", userId);
                    tx.put("adminId", admin.id);
                    tx.put("adminName", admin.name);
                    tx.put("adminImg", admin.img);
                    tx.put("amount", amtStr);
                    tx.put("accounts", count);
                    tx.put("country", selectedCountry);
                    tx.put("method", method);
                    tx.put("rate", String.format(Locale.US, "%.2f", rate));
                    tx.put("bdt", String.format(Locale.US, "%.2f", bdt));
                    tx.put("status", "pending");
                    tx.put("time", nowLabel());
                    tx.put("timestamp", ServerValue.TIMESTAMP);
                    Db.ref("transactions").child(txId).setValue(tx);
                }

                String reqMsg = isBn
                        ? "📌 [ডলার বিক্রির আবেদন]\n"
                        + "• পরিমাণ: " + amtStr + " USD\n"
                        + "• মোট অ্যাকাউন্ট: " + count + " টি\n"
                        + "• দেশ: " + selectedCountry + "\n"
                        + "• পেমেন্ট মাধ্যম: " + method + "\n"
                        + "• টাকা: ৳" + String.format(Locale.US, "%.2f", bdt)
                        : "📌 [SELL REQUEST]\n"
                        + "• Amount: " + amtStr + " USD\n"
                        + "• Accounts: " + count + "\n"
                        + "• Country: " + selectedCountry + "\n"
                        + "• Payment via: " + method + "\n"
                        + "• BDT: ৳" + String.format(Locale.US, "%.2f", bdt);

                sendMessage(reqMsg, "request", txId == null ? "" : txId);
                d.dismiss();
            }
        });
        card.addView(send, UI.lp(UI.MATCH, UI.WRAP));

        UI.showCard(d, card);
    }
}
