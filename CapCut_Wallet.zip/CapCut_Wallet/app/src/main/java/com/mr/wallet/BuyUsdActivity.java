package com.mr.wallet;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class BuyUsdActivity extends AppCompatActivity {

    private TextView phoneValue, emailValue;
    private DatabaseReference settingsRef;
    private ValueEventListener settingsListener;

    private double ownerRate;
    private String userId;
    private boolean isBn;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent in = getIntent();
        ownerRate = in.getDoubleExtra("ownerRate", 0.0);
        userId = in.getStringExtra("userId");
        if (userId == null) userId = UserSession.getId(this);
        isBn = in.getBooleanExtra("isBn", true);

        final Context c = this;
        root = UI.col(c);
        root.setBackgroundColor(UI.BG);

        TextView title = UI.tv(c,
                isBn ? "ক্যাপকাট ওয়ালেট - ডলার কিনুন" : "CAPCUT WALLET - BUY USD",
                13, UI.WHITE, true);
        root.addView(UI.appBar(this, title));

        LinearLayout body = UI.col(c);
        body.setPadding(UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14), UI.dp(c, 14));

        LinearLayout toggle = UI.row(c);
        toggle.setBackground(UI.box(c, UI.CARD, 10, 0, 0));
        toggle.setPadding(UI.dp(c, 4), UI.dp(c, 4), UI.dp(c, 4), UI.dp(c, 4));

        TextView sell = UI.tv(c, isBn ? "ডলার বিক্রি" : "Sell USD", 10, UI.GREY, false);
        sell.setGravity(Gravity.CENTER);
        sell.setBackground(UI.clickable(c, 0, 8, 0, 0));
        sell.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 8));
        sell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BuyUsdActivity.this, AdminListActivity.class);
                i.putExtra("ownerRate", ownerRate);
                i.putExtra("userId", userId);
                i.putExtra("isBn", isBn);
                startActivity(i);
                finish();
            }
        });
        toggle.addView(sell, UI.lpw(0, UI.WRAP, 1f));

        TextView buy = UI.tv(c, isBn ? "ডলার কিনুন" : "Buy USD", 10, UI.BLACK, true);
        buy.setGravity(Gravity.CENTER);
        buy.setBackground(UI.box(c, UI.CYAN, 8, 0, 0));
        buy.setPadding(0, UI.dp(c, 8), 0, UI.dp(c, 8));
        toggle.addView(buy, UI.lpw(0, UI.WRAP, 1f));
        body.addView(toggle, UI.lp(UI.MATCH, UI.WRAP));
        body.addView(UI.vs(c, 16));

        LinearLayout notice = UI.col(c);
        notice.setGravity(Gravity.CENTER_HORIZONTAL);
        notice.setBackground(UI.box(c, UI.CARD, 14, UI.BORDER, 1));
        notice.setPadding(UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16));
        notice.addView(UI.icon(c, Icons.SHIELD, UI.LIGHT_BLUE_ACCENT, 28));
        notice.addView(UI.vs(c, 8));
        TextView noticeTitle = UI.tv(c, isBn ? "বিজ্ঞপ্তি: ডলার ক্রয়ের ভেরিফিকেশন"
                : "Notice: Buy USD Verification", 13, UI.WHITE, true);
        noticeTitle.setGravity(Gravity.CENTER);
        notice.addView(noticeTitle, UI.lp(UI.MATCH, UI.WRAP));
        notice.addView(UI.vs(c, 6));
        TextView noticeText = UI.tv(c, isBn
                ? "ডলার কিনতে সরাসরি ওনারের সাথে যোগাযোগ করে তথ্য প্রদান করুন। ভেরিফিকেশন শেষে ডলার কিনতে পারবেন।"
                : "To buy USD, please contact the Owner and submit required details. After verification, purchase USD.",
                10, UI.GREY, false);
        noticeText.setGravity(Gravity.CENTER);
        notice.addView(noticeText, UI.lp(UI.MATCH, UI.WRAP));
        body.addView(notice, UI.lp(UI.MATCH, UI.WRAP));
        body.addView(UI.vs(c, 14));

        LinearLayout contact = UI.col(c);
        contact.setBackground(UI.box(c, UI.CARD, 14, UI.BORDER, 1));
        contact.setPadding(UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16), UI.dp(c, 16));
        contact.addView(UI.tv(c, isBn ? "ওনারের যোগাযোগের তথ্য" : "OWNER CONTACT INFORMATION",
                9, UI.AMBER, true));
        contact.addView(UI.vs(c, 12));
        contact.addView(buildCopyableContactRow(
                isBn ? "ওনার মোবাইল নম্বর" : "Owner Direct Mobile", true),
                UI.lp(UI.MATCH, UI.WRAP));
        contact.addView(UI.vs(c, 10));
        contact.addView(buildCopyableContactRow(
                isBn ? "ওনার ইমেইল অ্যাড্রেস" : "Owner Support Email", false),
                UI.lp(UI.MATCH, UI.WRAP));
        body.addView(contact, UI.lp(UI.MATCH, UI.WRAP));

        root.addView(body, UI.lpw(UI.MATCH, 0, 1f));
        setContentView(root);

        settingsRef = Db.ref("system_settings");
        settingsListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot s) {
                Object p = s.child("buy_phone").getValue();
                Object e = s.child("buy_email").getValue();
                phoneValue.setText(p == null || String.valueOf(p).trim().isEmpty() ? "—" : String.valueOf(p).trim());
                emailValue.setText(e == null || String.valueOf(e).trim().isEmpty() ? "—" : String.valueOf(e).trim());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        };
        settingsRef.addValueEventListener(settingsListener);
    }

    @Override
    protected void onDestroy() {
        if (settingsRef != null && settingsListener != null) settingsRef.removeEventListener(settingsListener);
        super.onDestroy();
    }

    private View buildCopyableContactRow(String label, final boolean isPhone) {
        Context c = this;
        LinearLayout row = UI.row(c);
        row.setBackground(UI.box(c, UI.BG, 8, 0, 0));
        row.setPadding(UI.dp(c, 12), UI.dp(c, 4), UI.dp(c, 4), UI.dp(c, 4));

        LinearLayout texts = UI.col(c);
        texts.addView(UI.tv(c, label, 8, UI.GREY, false));
        texts.addView(UI.vs(c, 2));
        final TextView valueView = UI.tv(c, "...", 11, UI.WHITE, true);
        if (isPhone) phoneValue = valueView; else emailValue = valueView;
        texts.addView(valueView);
        row.addView(texts, UI.lpw(0, UI.WRAP, 1f));

        row.addView(UI.iconButton(c, Icons.COPY, UI.AMBER, 16, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = valueView.getText().toString();
                if (value.equals("—") || value.equals("...")) return;
                UI.copyToClipboard(BuyUsdActivity.this, value);
                UI.snack(root,
                        isBn ? value + " কপি করা হয়েছে!" : "Copied " + value + " to clipboard!",
                        0, Snackbar.LENGTH_SHORT);
            }
        }));
        return row;
    }
}
